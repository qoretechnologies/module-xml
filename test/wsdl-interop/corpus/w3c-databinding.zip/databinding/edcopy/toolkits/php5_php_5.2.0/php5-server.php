<?php
       
    function dump($name, $o, $file="./snippets.html")
    {
	$log = fopen($file, 'a');
	fwrite($log, "\n");
	fwrite($log, "<b id='$name'>\$$name</b> = ");
	fwrite($log, "<pre>");
	$php = var_export($o, TRUE);
	fwrite($log, $php);
	fwrite($log, "</pre>");
	fwrite($log, "\n");
	fclose($log);
    }
    
    function echoAnySimpleTypeElement($o) 
    {
	dump("echoAnySimpleTypeElement", $o);
	return $o;
    } 

    function echoAnyTypeElement($o) 
    {
	dump("echoAnyTypeElement", $o);
	return $o;
    } 

    function echoDocumentationElement($o) 
    {
	dump("echoDocumentationElement", $o);
	return $o;
    } 

    function echoIdentifierName($o) 
    {
	dump("echoIdentifierName", $o);
	return $o;
    } 

    function echoNonIdentifierName($o) 
    {
	dump("echoNonIdentifierName", $o);
	return $o;
    } 

    function echoStringElement($o) 
    {
	dump("echoStringElement", $o);
	return $o;
    } 

    function echoStringAttribute($o) 
    {
	dump("echoStringAttribute", $o);
	return $o;
    } 

    function echoBooleanElement($o) 
    {
	dump("echoBooleanElement", $o);
	return $o;
    } 

    function echoBooleanAttribute($o) 
    {
	dump("echoBooleanAttribute", $o);
	return $o;
    } 

    function echoDecimalElement($o) 
    {
	dump("echoDecimalElement", $o);
	return $o;
    } 

    function echoDecimalAttribute($o) 
    {
	dump("echoDecimalAttribute", $o);
	return $o;
    } 

    function echoFloatElement($o) 
    {
	dump("echoFloatElement", $o);
	return $o;
    } 

    function echoFloatAttribute($o) 
    {
	dump("echoFloatAttribute", $o);
	return $o;
    } 

    function echoDoubleElement($o) 
    {
	dump("echoDoubleElement", $o);
	return $o;
    } 

    function echoDoubleAttribute($o) 
    {
	dump("echoDoubleAttribute", $o);
	return $o;
    } 

    function echoDurationElement($o) 
    {
	dump("echoDurationElement", $o);
	return $o;
    } 

    function echoDurationAttribute($o) 
    {
	dump("echoDurationAttribute", $o);
	return $o;
    } 

    function echoDateTimeElement($o) 
    {
	dump("echoDateTimeElement", $o);
	return $o;
    } 

    function echoDateTimeAttribute($o) 
    {
	dump("echoDateTimeAttribute", $o);
	return $o;
    } 

    function echoTimeElement($o) 
    {
	dump("echoTimeElement", $o);
	return $o;
    } 

    function echoTimeAttribute($o) 
    {
	dump("echoTimeAttribute", $o);
	return $o;
    } 

    function echoDateElement($o) 
    {
	dump("echoDateElement", $o);
	return $o;
    } 

    function echoDateAttribute($o) 
    {
	dump("echoDateAttribute", $o);
	return $o;
    } 

    function echoGYearMonthElement($o) 
    {
	dump("echoGYearMonthElement", $o);
	return $o;
    } 

    function echoGYearMonthAttribute($o) 
    {
	dump("echoGYearMonthAttribute", $o);
	return $o;
    } 

    function echoGYearElement($o) 
    {
	dump("echoGYearElement", $o);
	return $o;
    } 

    function echoGYearAttribute($o) 
    {
	dump("echoGYearAttribute", $o);
	return $o;
    } 

    function echoGMonthDayElement($o) 
    {
	dump("echoGMonthDayElement", $o);
	return $o;
    } 

    function echoGMonthDayAttribute($o) 
    {
	dump("echoGMonthDayAttribute", $o);
	return $o;
    } 

    function echoGDayElement($o) 
    {
	dump("echoGDayElement", $o);
	return $o;
    } 

    function echoGDayAttribute($o) 
    {
	dump("echoGDayAttribute", $o);
	return $o;
    } 

    function echoGMonthElement($o) 
    {
	dump("echoGMonthElement", $o);
	return $o;
    } 

    function echoGMonthAttribute($o) 
    {
	dump("echoGMonthAttribute", $o);
	return $o;
    } 

    function echoHexBinaryElement($o) 
    {
	dump("echoHexBinaryElement", $o);
	return $o;
    } 

    function echoHexBinaryAttribute($o) 
    {
	dump("echoHexBinaryAttribute", $o);
	return $o;
    } 

    function echoBase64BinaryElement($o) 
    {
	dump("echoBase64BinaryElement", $o);
	return $o;
    } 

    function echoBase64BinaryAttribute($o) 
    {
	dump("echoBase64BinaryAttribute", $o);
	return $o;
    } 

    function echoAnyURIElement($o) 
    {
	dump("echoAnyURIElement", $o);
	return $o;
    } 

    function echoAnyURIAttribute($o) 
    {
	dump("echoAnyURIAttribute", $o);
	return $o;
    } 

    function echoQNameElement($o) 
    {
	dump("echoQNameElement", $o);
	return $o;
    } 

    function echoQNameAttribute($o) 
    {
	dump("echoQNameAttribute", $o);
	return $o;
    } 

    function echoNormalizedStringElement($o) 
    {
	dump("echoNormalizedStringElement", $o);
	return $o;
    } 

    function echoNormalizedStringAttribute($o) 
    {
	dump("echoNormalizedStringAttribute", $o);
	return $o;
    } 

    function echoTokenElement($o) 
    {
	dump("echoTokenElement", $o);
	return $o;
    } 

    function echoTokenAttribute($o) 
    {
	dump("echoTokenAttribute", $o);
	return $o;
    } 

    function echoLanguageElement($o) 
    {
	dump("echoLanguageElement", $o);
	return $o;
    } 

    function echoLanguageAttribute($o) 
    {
	dump("echoLanguageAttribute", $o);
	return $o;
    } 

    function echoNMTOKENElement($o) 
    {
	dump("echoNMTOKENElement", $o);
	return $o;
    } 

    function echoNMTOKENAttribute($o) 
    {
	dump("echoNMTOKENAttribute", $o);
	return $o;
    } 

    function echoNMTOKENSElement($o) 
    {
	dump("echoNMTOKENSElement", $o);
	return $o;
    } 

    function echoNMTOKENSAttribute($o) 
    {
	dump("echoNMTOKENSAttribute", $o);
	return $o;
    } 

    function echoNameElement($o) 
    {
	dump("echoNameElement", $o);
	return $o;
    } 

    function echoNameAttribute($o) 
    {
	dump("echoNameAttribute", $o);
	return $o;
    } 

    function echoNCNameElement($o) 
    {
	dump("echoNCNameElement", $o);
	return $o;
    } 

    function echoNCNameAttribute($o) 
    {
	dump("echoNCNameAttribute", $o);
	return $o;
    } 

    function echoIDElement($o) 
    {
	dump("echoIDElement", $o);
	return $o;
    } 

    function echoIDAttribute($o) 
    {
	dump("echoIDAttribute", $o);
	return $o;
    } 

    function echoIDREFElement($o) 
    {
	dump("echoIDREFElement", $o);
	return $o;
    } 

    function echoIDREFAttribute($o) 
    {
	dump("echoIDREFAttribute", $o);
	return $o;
    } 

    function echoIDREFSElement($o) 
    {
	dump("echoIDREFSElement", $o);
	return $o;
    } 

    function echoIDREFSAttribute($o) 
    {
	dump("echoIDREFSAttribute", $o);
	return $o;
    } 

    function echoENTITYElement($o) 
    {
	dump("echoENTITYElement", $o);
	return $o;
    } 

    function echoENTITYAttribute($o) 
    {
	dump("echoENTITYAttribute", $o);
	return $o;
    } 

    function echoENTITIESElement($o) 
    {
	dump("echoENTITIESElement", $o);
	return $o;
    } 

    function echoENTITIESAttribute($o) 
    {
	dump("echoENTITIESAttribute", $o);
	return $o;
    } 

    function echoIntegerElement($o) 
    {
	dump("echoIntegerElement", $o);
	return $o;
    } 

    function echoIntegerAttribute($o) 
    {
	dump("echoIntegerAttribute", $o);
	return $o;
    } 

    function echoNonPositiveIntegerElement($o) 
    {
	dump("echoNonPositiveIntegerElement", $o);
	return $o;
    } 

    function echoNonPositiveIntegerAttribute($o) 
    {
	dump("echoNonPositiveIntegerAttribute", $o);
	return $o;
    } 

    function echoNegativeIntegerElement($o) 
    {
	dump("echoNegativeIntegerElement", $o);
	return $o;
    } 

    function echoLongElement($o) 
    {
	dump("echoLongElement", $o);
	return $o;
    } 

    function echoLongAttribute($o) 
    {
	dump("echoLongAttribute", $o);
	return $o;
    } 

    function echoIntElement($o) 
    {
	dump("echoIntElement", $o);
	return $o;
    } 

    function echoIntAttribute($o) 
    {
	dump("echoIntAttribute", $o);
	return $o;
    } 

    function echoShortElement($o) 
    {
	dump("echoShortElement", $o);
	return $o;
    } 

    function echoShortAttribute($o) 
    {
	dump("echoShortAttribute", $o);
	return $o;
    } 

    function echoByteElement($o) 
    {
	dump("echoByteElement", $o);
	return $o;
    } 

    function echoByteAttribute($o) 
    {
	dump("echoByteAttribute", $o);
	return $o;
    } 

    function echoNonNegativeIntegerElement($o) 
    {
	dump("echoNonNegativeIntegerElement", $o);
	return $o;
    } 

    function echoNonNegativeIntegerAttribute($o) 
    {
	dump("echoNonNegativeIntegerAttribute", $o);
	return $o;
    } 

    function echoUnsignedLongElement($o) 
    {
	dump("echoUnsignedLongElement", $o);
	return $o;
    } 

    function echoUnsignedLongAttribute($o) 
    {
	dump("echoUnsignedLongAttribute", $o);
	return $o;
    } 

    function echoUnsignedIntElement($o) 
    {
	dump("echoUnsignedIntElement", $o);
	return $o;
    } 

    function echoUnsignedIntAttribute($o) 
    {
	dump("echoUnsignedIntAttribute", $o);
	return $o;
    } 

    function echoUnsignedShortElement($o) 
    {
	dump("echoUnsignedShortElement", $o);
	return $o;
    } 

    function echoUnsignedShortAttribute($o) 
    {
	dump("echoUnsignedShortAttribute", $o);
	return $o;
    } 

    function echoNegativeIntegerAttribute($o) 
    {
	dump("echoNegativeIntegerAttribute", $o);
	return $o;
    } 

    function echoUnsignedByteElement($o) 
    {
	dump("echoUnsignedByteElement", $o);
	return $o;
    } 

    function echoUnsignedByteAttribute($o) 
    {
	dump("echoUnsignedByteAttribute", $o);
	return $o;
    } 

    function echoPositiveIntegerElement($o) 
    {
	dump("echoPositiveIntegerElement", $o);
	return $o;
    } 

    function echoPositiveIntegerAttribute($o) 
    {
	dump("echoPositiveIntegerAttribute", $o);
	return $o;
    } 

    function echoGlobalSimpleType($o) 
    {
	dump("echoGlobalSimpleType", $o);
	return $o;
    } 

    function echoStringEnumerationType($o) 
    {
	dump("echoStringEnumerationType", $o);
	return $o;
    } 

    function echoNMTOKENEnumerationType($o) 
    {
	dump("echoNMTOKENEnumerationType", $o);
	return $o;
    } 

    function echoIntEnumerationType($o) 
    {
	dump("echoIntEnumerationType", $o);
	return $o;
    } 

    function echoShortEnumerationType($o) 
    {
	dump("echoShortEnumerationType", $o);
	return $o;
    } 

    function echoLongEnumerationType($o) 
    {
	dump("echoLongEnumerationType", $o);
	return $o;
    } 

    function echoDoubleEnumerationType($o) 
    {
	dump("echoDoubleEnumerationType", $o);
	return $o;
    } 

    function echoIntegerEnumerationType($o) 
    {
	dump("echoIntegerEnumerationType", $o);
	return $o;
    } 

    function echoDecimalEnumerationType($o) 
    {
	dump("echoDecimalEnumerationType", $o);
	return $o;
    } 

    function echoFloatEnumerationType($o) 
    {
	dump("echoFloatEnumerationType", $o);
	return $o;
    } 

    function echoNonNegativeIntegerEnumerationType($o) 
    {
	dump("echoNonNegativeIntegerEnumerationType", $o);
	return $o;
    } 

    function echoPositiveIntegerEnumerationType($o) 
    {
	dump("echoPositiveIntegerEnumerationType", $o);
	return $o;
    } 

    function echoUnsignedLongEnumerationType($o) 
    {
	dump("echoUnsignedLongEnumerationType", $o);
	return $o;
    } 

    function echoUnsignedIntEnumerationType($o) 
    {
	dump("echoUnsignedIntEnumerationType", $o);
	return $o;
    } 

    function echoUnsignedShortEnumerationType($o) 
    {
	dump("echoUnsignedShortEnumerationType", $o);
	return $o;
    } 

    function echoTokenEnumerationType($o) 
    {
	dump("echoTokenEnumerationType", $o);
	return $o;
    } 

    function echoComplexTypeSequence($o) 
    {
	dump("echoComplexTypeSequence", $o);
	return $o;
    } 

    function echoComplexTypeAll($o) 
    {
	dump("echoComplexTypeAll", $o);
	return $o;
    } 

    function echoComplexTypeChoice($o) 
    {
	dump("echoComplexTypeChoice", $o);
	return $o;
    } 

    function echoComplexTypeSequenceChoice($o) 
    {
	dump("echoComplexTypeSequenceChoice", $o);
	return $o;
    } 

    function echoElementMinOccurs1($o) 
    {
	dump("echoElementMinOccurs1", $o);
	return $o;
    } 

    function echoElementMinOccurs2MaxOccurs2($o) 
    {
	dump("echoElementMinOccurs2MaxOccurs2", $o);
	return $o;
    } 

    function echoElementMinOccurs2orMore($o) 
    {
	dump("echoElementMinOccurs2orMore", $o);
	return $o;
    } 

    function echoElementMaxOccurs1($o) 
    {
	dump("echoElementMaxOccurs1", $o);
	return $o;
    } 

    function echoElementMaxOccursUnbounded($o) 
    {
	dump("echoElementMaxOccursUnbounded", $o);
	return $o;
    } 

    function echoElementMaxOccursFinite($o) 
    {
	dump("echoElementMaxOccursFinite", $o);
	return $o;
    } 

    function echoAttributeOptional($o) 
    {
	dump("echoAttributeOptional", $o);
	return $o;
    } 

    function echoAttributeRequired($o) 
    {
	dump("echoAttributeRequired", $o);
	return $o;
    } 

    function echoAttributeFixed($o) 
    {
	dump("echoAttributeFixed", $o);
	return $o;
    } 

    function echoAttributeDefault($o) 
    {
	dump("echoAttributeDefault", $o);
	return $o;
    } 

    function echoGlobalElementDefault($o) 
    {
	dump("echoGlobalElementDefault", $o);
	return $o;
    } 

    function echoLocalElementDefault($o) 
    {
	dump("echoLocalElementDefault", $o);
	return $o;
    } 

    function echoElementMinOccurs0($o) 
    {
	dump("echoElementMinOccurs0", $o);
	return $o;
    } 

    function echoNillableElement($o) 
    {
	dump("echoNillableElement", $o);
	return $o;
    } 

    function echoNillableOptionalElement($o) 
    {
	dump("echoNillableOptionalElement", $o);
	return $o;
    } 

    function echoUnionMemberTypes($o) 
    {
	dump("echoUnionMemberTypes", $o);
	return $o;
    } 

    function echoUnionDateString($o) 
    {
	dump("echoUnionDateString", $o);
	return $o;
    } 

    function echoUnionSimpleDateString($o) 
    {
	dump("echoUnionSimpleDateString", $o);
	return $o;
    } 

    function echoNullEnumerationType($o) 
    {
	dump("echoNullEnumerationType", $o);
	return $o;
    } 

    function echoElementEmptyComplexType($o) 
    {
	dump("echoElementEmptyComplexType", $o);
	return $o;
    } 

    function echoElementEmptySequence($o) 
    {
	dump("echoElementEmptySequence", $o);
	return $o;
    } 

    function echoGlobalElementSequence($o) 
    {
	dump("echoGlobalElementSequence", $o);
	return $o;
    } 

    function echoSequenceElementList($o) 
    {
	dump("echoSequenceElementList", $o);
	return $o;
    } 

    function echoNestedSequenceElementList($o) 
    {
	dump("echoNestedSequenceElementList", $o);
	return $o;
    } 

    function echoMixedContentType($o) 
    {
	dump("echoMixedContentType", $o);
	return $o;
    } 

    function echoStringSimpleTypePattern($o) 
    {
	dump("echoStringSimpleTypePattern", $o);
	return $o;
    } 

    function echoIntSimpleTypePattern($o) 
    {
	dump("echoIntSimpleTypePattern", $o);
	return $o;
    } 

    function echoIntegerSimpleTypePattern($o) 
    {
	dump("echoIntegerSimpleTypePattern", $o);
	return $o;
    } 

    function echoLongSimpleTypePattern($o) 
    {
	dump("echoLongSimpleTypePattern", $o);
	return $o;
    } 

    function echoDecimalSimpleTypePattern($o) 
    {
	dump("echoDecimalSimpleTypePattern", $o);
	return $o;
    } 

    function echoFloatSimpleTypePattern($o) 
    {
	dump("echoFloatSimpleTypePattern", $o);
	return $o;
    } 

    function echoDoubleSimpleTypePattern($o) 
    {
	dump("echoDoubleSimpleTypePattern", $o);
	return $o;
    } 

    function echoShortSimpleTypePattern($o) 
    {
	dump("echoShortSimpleTypePattern", $o);
	return $o;
    } 

    function echoNonNegativeIntegerSimpleTypePattern($o) 
    {
	dump("echoNonNegativeIntegerSimpleTypePattern", $o);
	return $o;
    } 

    function echoPositiveIntegerSimpleTypePattern($o) 
    {
	dump("echoPositiveIntegerSimpleTypePattern", $o);
	return $o;
    } 

    function echoUnsignedLongSimpleTypePattern($o) 
    {
	dump("echoUnsignedLongSimpleTypePattern", $o);
	return $o;
    } 

    function echoUnsignedIntSimpleTypePattern($o) 
    {
	dump("echoUnsignedIntSimpleTypePattern", $o);
	return $o;
    } 

    function echoUnsignedShortSimpleTypePattern($o) 
    {
	dump("echoUnsignedShortSimpleTypePattern", $o);
	return $o;
    } 

    function echoDateSimpleTypePattern($o) 
    {
	dump("echoDateSimpleTypePattern", $o);
	return $o;
    } 

    function echoRestrictedMinInclusive($o) 
    {
	dump("echoRestrictedMinInclusive", $o);
	return $o;
    } 

    function echoRestrictedMaxInclusive($o) 
    {
	dump("echoRestrictedMaxInclusive", $o);
	return $o;
    } 

    function echoRestrictedMinExclusive($o) 
    {
	dump("echoRestrictedMinExclusive", $o);
	return $o;
    } 

    function echoRestrictedMaxExclusive($o) 
    {
	dump("echoRestrictedMaxExclusive", $o);
	return $o;
    } 

    function echoRestrictedLength($o) 
    {
	dump("echoRestrictedLength", $o);
	return $o;
    } 

    function echoRestrictedMaxLength($o) 
    {
	dump("echoRestrictedMaxLength", $o);
	return $o;
    } 

    function echoRestrictedMinLength($o) 
    {
	dump("echoRestrictedMinLength", $o);
	return $o;
    } 

    function echoAnyAttributeStrict($o) 
    {
	dump("echoAnyAttributeStrict", $o);
	return $o;
    } 

    function echoAnyAttributeSkip($o) 
    {
	dump("echoAnyAttributeSkip", $o);
	return $o;
    } 

    function echoAnyAttributeLax($o) 
    {
	dump("echoAnyAttributeLax", $o);
	return $o;
    } 

    function echoElementReference($o) 
    {
	dump("echoElementReference", $o);
	return $o;
    } 

    function echoAttributeReference($o) 
    {
	dump("echoAttributeReference", $o);
	return $o;
    } 

    function echoAttributeElementNameClash($o) 
    {
	dump("echoAttributeElementNameClash", $o);
	return $o;
    } 

    function echoExtendedSequenceStrict($o) 
    {
	dump("echoExtendedSequenceStrict", $o);
	return $o;
    } 

    function echoExtendedSequenceLax($o) 
    {
	dump("echoExtendedSequenceLax", $o);
	return $o;
    } 

    function echoExtendedSequenceSkip($o) 
    {
	dump("echoExtendedSequenceSkip", $o);
	return $o;
    } 

    function echoElementTypeDefaultNamespace($o) 
    {
	dump("echoElementTypeDefaultNamespace", $o);
	return $o;
    } 

    function echoRestrictedStringMinLength($o) 
    {
	dump("echoRestrictedStringMinLength", $o);
	return $o;
    } 

    function echoRestrictedStringMaxLength($o) 
    {
	dump("echoRestrictedStringMaxLength", $o);
	return $o;
    } 

    function echoRestrictedStringMinMaxLength($o) 
    {
	dump("echoRestrictedStringMinMaxLength", $o);
	return $o;
    } 

    function echoBareVector($o) 
    {
	dump("echoBareVector", $o);
	return $o;
    } 

    function echoComplexTypeSequenceExtension($o) 
    {
	dump("echoComplexTypeSequenceExtension", $o);
	return $o;
    } 

    function echoTypeSubstitutionUsingXsiType($o) 
    {
	dump("echoTypeSubstitutionUsingXsiType", $o);
	return $o;
    } 

    function echoSimpleTypeAttributes($o) 
    {
	dump("echoSimpleTypeAttributes", $o);
	return $o;
    } 

    function echoPrecisionDecimal($o) 
    {
	dump("echoPrecisionDecimal", $o);
	return $o;
    } 

    function echoExtendedSimpleType($o) 
    {
	dump("echoExtendedSimpleType", $o);
	return $o;
    } 

    function echoSequenceMinOccurs1($o) 
    {
	dump("echoSequenceMinOccurs1", $o);
	return $o;
    } 

    function echoSequenceMinOccursFinite($o) 
    {
	dump("echoSequenceMinOccursFinite", $o);
	return $o;
    } 

    function echoSequenceMaxOccurs1($o) 
    {
	dump("echoSequenceMaxOccurs1", $o);
	return $o;
    } 

    function echoElementMinOccurs0MaxOccursUnbounded($o) 
    {
	dump("echoElementMinOccurs0MaxOccursUnbounded", $o);
	return $o;
    } 

    function echoSequenceMinOccurs0MaxOccursUnbounded($o) 
    {
	dump("echoSequenceMinOccurs0MaxOccursUnbounded", $o);
	return $o;
    } 

    function echoElementMinOccurs1MaxOccursUnbounded($o) 
    {
	dump("echoElementMinOccurs1MaxOccursUnbounded", $o);
	return $o;
    } 

    function echoSequenceMinOccurs1MaxOccursUnbounded($o) 
    {
	dump("echoSequenceMinOccurs1MaxOccursUnbounded", $o);
	return $o;
    } 

    function echoSequenceMaxOccursUnbounded($o) 
    {
	dump("echoSequenceMaxOccursUnbounded", $o);
	return $o;
    } 

    function echoSequenceMaxOccursFinite($o) 
    {
	dump("echoSequenceMaxOccursFinite", $o);
	return $o;
    } 

    function echoSequenceMinOccurs0($o) 
    {
	dump("echoSequenceMinOccurs0", $o);
	return $o;
    } 

    function echoSequenceSequenceElement($o) 
    {
	dump("echoSequenceSequenceElement", $o);
	return $o;
    } 

    function echoDecimalSimpleTypeTotalDigits($o) 
    {
	dump("echoDecimalSimpleTypeTotalDigits", $o);
	return $o;
    } 

    function echoDecimalSimpleTypeFractionDigits($o) 
    {
	dump("echoDecimalSimpleTypeFractionDigits", $o);
	return $o;
    } 

    function echoAttributeTypeReference($o) 
    {
	dump("echoAttributeTypeReference", $o);
	return $o;
    } 

    function echoElementTypeReference($o) 
    {
	dump("echoElementTypeReference", $o);
	return $o;
    } 

    function echoLocalElementComplexType($o) 
    {
	dump("echoLocalElementComplexType", $o);
	return $o;
    } 

    function echoIdExample($o) 
    {
	dump("echoIdExample", $o);
	return $o;
    } 

    function echoAttributeGroupExample($o) 
    {
	dump("echoAttributeGroupExample", $o);
	return $o;
    } 


    $server = new SoapServer("examples.wsdl");

    $server->addFunction("echoAnySimpleTypeElement");$server->addFunction("echoAnyTypeElement");$server->addFunction("echoDocumentationElement");$server->addFunction("echoIdentifierName");$server->addFunction("echoNonIdentifierName");$server->addFunction("echoStringElement");$server->addFunction("echoStringAttribute");$server->addFunction("echoBooleanElement");$server->addFunction("echoBooleanAttribute");$server->addFunction("echoDecimalElement");$server->addFunction("echoDecimalAttribute");$server->addFunction("echoFloatElement");$server->addFunction("echoFloatAttribute");$server->addFunction("echoDoubleElement");$server->addFunction("echoDoubleAttribute");$server->addFunction("echoDurationElement");$server->addFunction("echoDurationAttribute");$server->addFunction("echoDateTimeElement");$server->addFunction("echoDateTimeAttribute");$server->addFunction("echoTimeElement");$server->addFunction("echoTimeAttribute");$server->addFunction("echoDateElement");$server->addFunction("echoDateAttribute");$server->addFunction("echoGYearMonthElement");$server->addFunction("echoGYearMonthAttribute");$server->addFunction("echoGYearElement");$server->addFunction("echoGYearAttribute");$server->addFunction("echoGMonthDayElement");$server->addFunction("echoGMonthDayAttribute");$server->addFunction("echoGDayElement");$server->addFunction("echoGDayAttribute");$server->addFunction("echoGMonthElement");$server->addFunction("echoGMonthAttribute");$server->addFunction("echoHexBinaryElement");$server->addFunction("echoHexBinaryAttribute");$server->addFunction("echoBase64BinaryElement");$server->addFunction("echoBase64BinaryAttribute");$server->addFunction("echoAnyURIElement");$server->addFunction("echoAnyURIAttribute");$server->addFunction("echoQNameElement");$server->addFunction("echoQNameAttribute");$server->addFunction("echoNormalizedStringElement");$server->addFunction("echoNormalizedStringAttribute");$server->addFunction("echoTokenElement");$server->addFunction("echoTokenAttribute");$server->addFunction("echoLanguageElement");$server->addFunction("echoLanguageAttribute");$server->addFunction("echoNMTOKENElement");$server->addFunction("echoNMTOKENAttribute");$server->addFunction("echoNMTOKENSElement");$server->addFunction("echoNMTOKENSAttribute");$server->addFunction("echoNameElement");$server->addFunction("echoNameAttribute");$server->addFunction("echoNCNameElement");$server->addFunction("echoNCNameAttribute");$server->addFunction("echoIDElement");$server->addFunction("echoIDAttribute");$server->addFunction("echoIDREFElement");$server->addFunction("echoIDREFAttribute");$server->addFunction("echoIDREFSElement");$server->addFunction("echoIDREFSAttribute");$server->addFunction("echoENTITYElement");$server->addFunction("echoENTITYAttribute");$server->addFunction("echoENTITIESElement");$server->addFunction("echoENTITIESAttribute");$server->addFunction("echoIntegerElement");$server->addFunction("echoIntegerAttribute");$server->addFunction("echoNonPositiveIntegerElement");$server->addFunction("echoNonPositiveIntegerAttribute");$server->addFunction("echoNegativeIntegerElement");$server->addFunction("echoLongElement");$server->addFunction("echoLongAttribute");$server->addFunction("echoIntElement");$server->addFunction("echoIntAttribute");$server->addFunction("echoShortElement");$server->addFunction("echoShortAttribute");$server->addFunction("echoByteElement");$server->addFunction("echoByteAttribute");$server->addFunction("echoNonNegativeIntegerElement");$server->addFunction("echoNonNegativeIntegerAttribute");$server->addFunction("echoUnsignedLongElement");$server->addFunction("echoUnsignedLongAttribute");$server->addFunction("echoUnsignedIntElement");$server->addFunction("echoUnsignedIntAttribute");$server->addFunction("echoUnsignedShortElement");$server->addFunction("echoUnsignedShortAttribute");$server->addFunction("echoNegativeIntegerAttribute");$server->addFunction("echoUnsignedByteElement");$server->addFunction("echoUnsignedByteAttribute");$server->addFunction("echoPositiveIntegerElement");$server->addFunction("echoPositiveIntegerAttribute");$server->addFunction("echoGlobalSimpleType");$server->addFunction("echoStringEnumerationType");$server->addFunction("echoNMTOKENEnumerationType");$server->addFunction("echoIntEnumerationType");$server->addFunction("echoShortEnumerationType");$server->addFunction("echoLongEnumerationType");$server->addFunction("echoDoubleEnumerationType");$server->addFunction("echoIntegerEnumerationType");$server->addFunction("echoDecimalEnumerationType");$server->addFunction("echoFloatEnumerationType");$server->addFunction("echoNonNegativeIntegerEnumerationType");$server->addFunction("echoPositiveIntegerEnumerationType");$server->addFunction("echoUnsignedLongEnumerationType");$server->addFunction("echoUnsignedIntEnumerationType");$server->addFunction("echoUnsignedShortEnumerationType");$server->addFunction("echoTokenEnumerationType");$server->addFunction("echoComplexTypeSequence");$server->addFunction("echoComplexTypeAll");$server->addFunction("echoComplexTypeChoice");$server->addFunction("echoComplexTypeSequenceChoice");$server->addFunction("echoElementMinOccurs1");$server->addFunction("echoElementMinOccurs2MaxOccurs2");$server->addFunction("echoElementMinOccurs2orMore");$server->addFunction("echoElementMaxOccurs1");$server->addFunction("echoElementMaxOccursUnbounded");$server->addFunction("echoElementMaxOccursFinite");$server->addFunction("echoAttributeOptional");$server->addFunction("echoAttributeRequired");$server->addFunction("echoAttributeFixed");$server->addFunction("echoAttributeDefault");$server->addFunction("echoGlobalElementDefault");$server->addFunction("echoLocalElementDefault");$server->addFunction("echoElementMinOccurs0");$server->addFunction("echoNillableElement");$server->addFunction("echoNillableOptionalElement");$server->addFunction("echoUnionMemberTypes");$server->addFunction("echoUnionDateString");$server->addFunction("echoUnionSimpleDateString");$server->addFunction("echoNullEnumerationType");$server->addFunction("echoElementEmptyComplexType");$server->addFunction("echoElementEmptySequence");$server->addFunction("echoGlobalElementSequence");$server->addFunction("echoSequenceElementList");$server->addFunction("echoNestedSequenceElementList");$server->addFunction("echoMixedContentType");$server->addFunction("echoStringSimpleTypePattern");$server->addFunction("echoIntSimpleTypePattern");$server->addFunction("echoIntegerSimpleTypePattern");$server->addFunction("echoLongSimpleTypePattern");$server->addFunction("echoDecimalSimpleTypePattern");$server->addFunction("echoFloatSimpleTypePattern");$server->addFunction("echoDoubleSimpleTypePattern");$server->addFunction("echoShortSimpleTypePattern");$server->addFunction("echoNonNegativeIntegerSimpleTypePattern");$server->addFunction("echoPositiveIntegerSimpleTypePattern");$server->addFunction("echoUnsignedLongSimpleTypePattern");$server->addFunction("echoUnsignedIntSimpleTypePattern");$server->addFunction("echoUnsignedShortSimpleTypePattern");$server->addFunction("echoDateSimpleTypePattern");$server->addFunction("echoRestrictedMinInclusive");$server->addFunction("echoRestrictedMaxInclusive");$server->addFunction("echoRestrictedMinExclusive");$server->addFunction("echoRestrictedMaxExclusive");$server->addFunction("echoRestrictedLength");$server->addFunction("echoRestrictedMaxLength");$server->addFunction("echoRestrictedMinLength");$server->addFunction("echoAnyAttributeStrict");$server->addFunction("echoAnyAttributeSkip");$server->addFunction("echoAnyAttributeLax");$server->addFunction("echoElementReference");$server->addFunction("echoAttributeReference");$server->addFunction("echoAttributeElementNameClash");$server->addFunction("echoExtendedSequenceStrict");$server->addFunction("echoExtendedSequenceLax");$server->addFunction("echoExtendedSequenceSkip");$server->addFunction("echoElementTypeDefaultNamespace");$server->addFunction("echoRestrictedStringMinLength");$server->addFunction("echoRestrictedStringMaxLength");$server->addFunction("echoRestrictedStringMinMaxLength");$server->addFunction("echoBareVector");$server->addFunction("echoComplexTypeSequenceExtension");$server->addFunction("echoTypeSubstitutionUsingXsiType");$server->addFunction("echoSimpleTypeAttributes");$server->addFunction("echoPrecisionDecimal");$server->addFunction("echoExtendedSimpleType");$server->addFunction("echoSequenceMinOccurs1");$server->addFunction("echoSequenceMinOccursFinite");$server->addFunction("echoSequenceMaxOccurs1");$server->addFunction("echoElementMinOccurs0MaxOccursUnbounded");$server->addFunction("echoSequenceMinOccurs0MaxOccursUnbounded");$server->addFunction("echoElementMinOccurs1MaxOccursUnbounded");$server->addFunction("echoSequenceMinOccurs1MaxOccursUnbounded");$server->addFunction("echoSequenceMaxOccursUnbounded");$server->addFunction("echoSequenceMaxOccursFinite");$server->addFunction("echoSequenceMinOccurs0");$server->addFunction("echoSequenceSequenceElement");$server->addFunction("echoDecimalSimpleTypeTotalDigits");$server->addFunction("echoDecimalSimpleTypeFractionDigits");$server->addFunction("echoAttributeTypeReference");$server->addFunction("echoElementTypeReference");$server->addFunction("echoLocalElementComplexType");$server->addFunction("echoIdExample");$server->addFunction("echoAttributeGroupExample");

    if ($_SERVER["REQUEST_METHOD"] == "POST")
    {
	$server->handle();
    } 
    else
    {
	echo "<pre>";
	echo "This SOAP server can handle following functions: \n";
	$functions = $server->getFunctions();
	foreach($functions as $func)
	{
	    echo "    "  . $func . "\n";
	}
	echo "</pre>";
    }

?>