#
#   environment
#
. ../setenv.sh

#
#  skipped patterns
#
exclusions=$(xsltproc $EXAMPLES_DIR/exclusions.xsl toolkit.xml)

#
#  generate bespoke wsdl
#
xsltproc  \
    --stringparam exclude "$exclusions" \
    $EXAMPLES_DIR/examples2wsdl.xsl \
    $EXAMPLES_DIR/examples.xml > examples.wsdl

#
#  generate server code
#
xsltproc ../php5_php_5.0.4/php5-server.xsl examples.wsdl > php5-server.php

#
#  generate source
#
php -s php5-server.php > php5-server.php.html
