#
#  common environment
#
#  $Header: /w3ccvs/WWW/2002/ws/databinding/edcopy/toolkits/xbinder_c_1.4/setenv.sh,v 1.1 2008/03/12 13:53:32 gcowe Exp $
#

#
#  default toolkit name
#  -the name of the current directory
#
export TOOLKIT=$(basename $PWD)

#
#  root of local copy of databinding files
#
[ -z "$DATABINDING_HOME" ]&&DATABINDING_HOME=../..
export DATABINDING_HOME

#
#  local copy of testsuite examples files
#
export EXAMPLES_DIR=${DATABINDING_HOME}/examples/6/09
