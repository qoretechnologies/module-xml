#include <stdsoap2.h>
#include <SoapBinding.nsmap>

main() {
  struct soap soap;
  soap_init(&soap);
  soap_set_namespaces(&soap, namespaces); 
  /*
    Interesting: setting this makes the nil test pass but a ton of others fail
  soap_set_omode(&soap, SOAP_XML_NIL);
  */
  if (!soap_valid_socket(soap_bind(&soap, NULL, 12345, 100))) {
    soap_print_fault(&soap, stderr);
    exit(1);
  }
  while (soap_valid_socket(soap_accept(&soap))) {
    if (soap_serve(&soap)) {
      soap_print_fault(&soap, stderr);
      soap_print_fault_location(&soap, stderr);
    }
    soap_end(&soap);
  }
}
