#!/bin/sh
#
#   include environment
#
. ./setenv.sh

for pattern in `../../patterns/listincluded`
do
   echo $pattern
   ./genit.sh ":${pattern}:"
    sleep 10
   PATH=/cygdrive/c/perl/bin ../runit.sh :${pattern}:
   mv output.xml dance/output-${pattern}.xml
done 2>&1 | tee dance.out

exit 0
