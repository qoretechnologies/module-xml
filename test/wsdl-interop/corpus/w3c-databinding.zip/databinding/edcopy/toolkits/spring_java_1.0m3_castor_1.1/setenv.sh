. ../setenv.sh
