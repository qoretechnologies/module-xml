<?xml version="1.0"?>
<!-- 

    Copyright (C) 2006 W3C (R) (MIT ERCIM Keio), All Rights Reserved.
    W3C liability, trademark and document use rules apply.

    http://www.w3.org/Consortium/Legal/ipr-notice
    http://www.w3.org/Consortium/Legal/copyright-documents

    $Header: /w3ccvs/WWW/2002/ws/databinding/edcopy/toolkits/spring_java_1.0m3_castor_1.1/basicpatternslist.xsl,v 1.3 2007/04/21 09:22:14 pdowney Exp $
-->


<xsl:stylesheet
    xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
    xmlns:ex="http://www.w3.org/2002/ws/databinding/patterns/6/09/"
    xmlns:xsl="http://www.w3.org/1999/XSL/Transform"
    version="1.0">

   <xsl:output method="text"/>

   <xsl:template match="/">

    <xsl:for-each select="/ex:patterns/ex:pattern[@status!='basic']">
		<xsl:variable name="m"><xsl:value-of select="./@xml:id"/></xsl:variable>
		<xsl:text>&lt;exclude&gt;</xsl:text><xsl:value-of select="$m"/><xsl:text>&lt;/exclude&gt;
		</xsl:text>
   </xsl:for-each>

   </xsl:template>
</xsl:stylesheet>
