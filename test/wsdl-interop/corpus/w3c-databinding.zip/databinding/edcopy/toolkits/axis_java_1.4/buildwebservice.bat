java -cp lib\dbwg-util.jar;lib\xercesImpl.jar;%ant_home%\lib\ant.jar;%ant_home%\lib\ant-launcher.jar;%ant_home%\lib\ant-trax.jar org.w3c.dbwg.wsdl.util.BuildWebService axis_java_1.4 
