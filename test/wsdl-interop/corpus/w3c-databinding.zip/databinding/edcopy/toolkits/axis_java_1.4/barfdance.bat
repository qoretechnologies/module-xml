java -cp lib\dbwg-util.jar;%ant_home%\lib\ant.jar;%ant_home%\lib\ant-launcher.jar;%ant_home%\lib\ant-trax.jar org.w3c.dbwg.wsdl.util.TestExamples http://localhost:8181/databinding_axis14/services/
