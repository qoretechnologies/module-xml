<?xml version="1.0" encoding="utf-8"?>
<!-- 

    Copyright (C) 2006 W3C (R) (MIT ERCIM Keio), All Rights Reserved.
    W3C liability, trademark and document use rules apply.

    http://www.w3.org/Consortium/Legal/ipr-notice
    http://www.w3.org/Consortium/Legal/copyright-documents

    $Header: /w3ccvs/WWW/2002/ws/databinding/edcopy/toolkits/axis_java_1.4/getexamples.xsl,v 1.1 2007/04/18 08:20:29 jigsaw Exp $

-->
<xsl:stylesheet xmlns:xs="http://www.w3.org/2001/XMLSchema" 
  xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
  xmlns:ex="http://www.w3.org/2002/ws/databinding/examples/6/09/"
  xmlns:xsl="http://www.w3.org/1999/XSL/Transform"
  version="1.0">
<xsl:output method="text"/>
<xsl:template match="/">
  <xsl:for-each select="//ex:example">
    <xsl:variable name="exampleId" select="./@xml:id"/>
      <xsl:value-of select="$exampleId"/>
      <xsl:text>&#x0D;</xsl:text>  
    </xsl:for-each>  
</xsl:template>    
</xsl:stylesheet>
