#!/bin/sh
#
#    Copyright (C) 2006 W3C (R) (MIT ERCIM Keio), All Rights Reserved.
#    W3C liability, trademark and document use rules apply.
#
#    http://www.w3.org/Consortium/Legal/ipr-notice
#    http://www.w3.org/Consortium/Legal/copyright-documents
#
#    $Header: /w3ccvs/WWW/2002/ws/databinding/edcopy/toolkits/barfdance.sh,v 1.2 2006/11/29 22:18:28 pdowney Exp $
#
#  try and find the individual example causing a tool to barf

. ../setenv.sh

for example in `$EXAMPLES_DIR/listexamples`
do
    param=":$example:"
    echo "$param"
    genit.sh "$param"
done 2>&1 | tee barfdance.out

exit
