. ../setenv.sh

export SOAP4R_DIR=$TOOLKITS_DIR/soap4r-1.5.8/
