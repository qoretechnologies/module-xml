require 'default.rb'

class PortType
  # SYNOPSIS
  #   echoAnySimpleTypeElement(echoAnySimpleTypeElementRequest)
  #
  # ARGS
  #   echoAnySimpleTypeElementRequest EchoAnySimpleTypeElement - {http://www.w3.org/2002/ws/databinding/examples/6/09/}echoAnySimpleTypeElement
  #
  # RETURNS
  #   echoAnySimpleTypeElementResponse EchoAnySimpleTypeElement - {http://www.w3.org/2002/ws/databinding/examples/6/09/}echoAnySimpleTypeElement
  #
  def echoAnySimpleTypeElement(echoAnySimpleTypeElementRequest)
    p [echoAnySimpleTypeElementRequest]
    return echoAnySimpleTypeElementRequest
  end

  # SYNOPSIS
  #   echoAnyTypeElement(echoAnyTypeElementRequest)
  #
  # ARGS
  #   echoAnyTypeElementRequest EchoAnyTypeElement - {http://www.w3.org/2002/ws/databinding/examples/6/09/}echoAnyTypeElement
  #
  # RETURNS
  #   echoAnyTypeElementResponse EchoAnyTypeElement - {http://www.w3.org/2002/ws/databinding/examples/6/09/}echoAnyTypeElement
  #
  def echoAnyTypeElement(echoAnyTypeElementRequest)
    p [echoAnyTypeElementRequest]
    return echoAnyTypeElementRequest
  end

  # SYNOPSIS
  #   echoDocumentationElement(echoDocumentationElementRequest)
  #
  # ARGS
  #   echoDocumentationElementRequest EchoDocumentationElement - {http://www.w3.org/2002/ws/databinding/examples/6/09/}echoDocumentationElement
  #
  # RETURNS
  #   echoDocumentationElementResponse EchoDocumentationElement - {http://www.w3.org/2002/ws/databinding/examples/6/09/}echoDocumentationElement
  #
  def echoDocumentationElement(echoDocumentationElementRequest)
    p [echoDocumentationElementRequest]
    return echoDocumentationElementRequest
  end

  # SYNOPSIS
  #   echoIdentifierName(echoIdentifierNameRequest)
  #
  # ARGS
  #   echoIdentifierNameRequest EchoIdentifierName - {http://www.w3.org/2002/ws/databinding/examples/6/09/}echoIdentifierName
  #
  # RETURNS
  #   echoIdentifierNameResponse EchoIdentifierName - {http://www.w3.org/2002/ws/databinding/examples/6/09/}echoIdentifierName
  #
  def echoIdentifierName(echoIdentifierNameRequest)
    p [echoIdentifierNameRequest]
    return echoIdentifierNameRequest
  end

  # SYNOPSIS
  #   echoNonIdentifierName(echoNonIdentifierNameRequest)
  #
  # ARGS
  #   echoNonIdentifierNameRequest EchoNonIdentifierName - {http://www.w3.org/2002/ws/databinding/examples/6/09/}echoNonIdentifierName
  #
  # RETURNS
  #   echoNonIdentifierNameResponse EchoNonIdentifierName - {http://www.w3.org/2002/ws/databinding/examples/6/09/}echoNonIdentifierName
  #
  def echoNonIdentifierName(echoNonIdentifierNameRequest)
    p [echoNonIdentifierNameRequest]
    return echoNonIdentifierNameRequest
  end

  # SYNOPSIS
  #   echoStringElement(echoStringElementRequest)
  #
  # ARGS
  #   echoStringElementRequest EchoStringElement - {http://www.w3.org/2002/ws/databinding/examples/6/09/}echoStringElement
  #
  # RETURNS
  #   echoStringElementResponse EchoStringElement - {http://www.w3.org/2002/ws/databinding/examples/6/09/}echoStringElement
  #
  def echoStringElement(echoStringElementRequest)
    p [echoStringElementRequest]
    return echoStringElementRequest
  end

  # SYNOPSIS
  #   echoStringAttribute(echoStringAttributeRequest)
  #
  # ARGS
  #   echoStringAttributeRequest EchoStringAttribute - {http://www.w3.org/2002/ws/databinding/examples/6/09/}echoStringAttribute
  #
  # RETURNS
  #   echoStringAttributeResponse EchoStringAttribute - {http://www.w3.org/2002/ws/databinding/examples/6/09/}echoStringAttribute
  #
  def echoStringAttribute(echoStringAttributeRequest)
    p [echoStringAttributeRequest]
    return echoStringAttributeRequest
  end

  # SYNOPSIS
  #   echoBooleanElement(echoBooleanElementRequest)
  #
  # ARGS
  #   echoBooleanElementRequest EchoBooleanElement - {http://www.w3.org/2002/ws/databinding/examples/6/09/}echoBooleanElement
  #
  # RETURNS
  #   echoBooleanElementResponse EchoBooleanElement - {http://www.w3.org/2002/ws/databinding/examples/6/09/}echoBooleanElement
  #
  def echoBooleanElement(echoBooleanElementRequest)
    p [echoBooleanElementRequest]
    return echoBooleanElementRequest
  end

  # SYNOPSIS
  #   echoBooleanAttribute(echoBooleanAttributeRequest)
  #
  # ARGS
  #   echoBooleanAttributeRequest EchoBooleanAttribute - {http://www.w3.org/2002/ws/databinding/examples/6/09/}echoBooleanAttribute
  #
  # RETURNS
  #   echoBooleanAttributeResponse EchoBooleanAttribute - {http://www.w3.org/2002/ws/databinding/examples/6/09/}echoBooleanAttribute
  #
  def echoBooleanAttribute(echoBooleanAttributeRequest)
    p [echoBooleanAttributeRequest]
    return echoBooleanAttributeRequest
  end

  # SYNOPSIS
  #   echoDecimalElement(echoDecimalElementRequest)
  #
  # ARGS
  #   echoDecimalElementRequest EchoDecimalElement - {http://www.w3.org/2002/ws/databinding/examples/6/09/}echoDecimalElement
  #
  # RETURNS
  #   echoDecimalElementResponse EchoDecimalElement - {http://www.w3.org/2002/ws/databinding/examples/6/09/}echoDecimalElement
  #
  def echoDecimalElement(echoDecimalElementRequest)
    p [echoDecimalElementRequest]
    return echoDecimalElementRequest
  end

  # SYNOPSIS
  #   echoDecimalAttribute(echoDecimalAttributeRequest)
  #
  # ARGS
  #   echoDecimalAttributeRequest EchoDecimalAttribute - {http://www.w3.org/2002/ws/databinding/examples/6/09/}echoDecimalAttribute
  #
  # RETURNS
  #   echoDecimalAttributeResponse EchoDecimalAttribute - {http://www.w3.org/2002/ws/databinding/examples/6/09/}echoDecimalAttribute
  #
  def echoDecimalAttribute(echoDecimalAttributeRequest)
    p [echoDecimalAttributeRequest]
    return echoDecimalAttributeRequest
  end

  # SYNOPSIS
  #   echoFloatElement(echoFloatElementRequest)
  #
  # ARGS
  #   echoFloatElementRequest EchoFloatElement - {http://www.w3.org/2002/ws/databinding/examples/6/09/}echoFloatElement
  #
  # RETURNS
  #   echoFloatElementResponse EchoFloatElement - {http://www.w3.org/2002/ws/databinding/examples/6/09/}echoFloatElement
  #
  def echoFloatElement(echoFloatElementRequest)
    p [echoFloatElementRequest]
    return echoFloatElementRequest
  end

  # SYNOPSIS
  #   echoFloatAttribute(echoFloatAttributeRequest)
  #
  # ARGS
  #   echoFloatAttributeRequest EchoFloatAttribute - {http://www.w3.org/2002/ws/databinding/examples/6/09/}echoFloatAttribute
  #
  # RETURNS
  #   echoFloatAttributeResponse EchoFloatAttribute - {http://www.w3.org/2002/ws/databinding/examples/6/09/}echoFloatAttribute
  #
  def echoFloatAttribute(echoFloatAttributeRequest)
    p [echoFloatAttributeRequest]
    return echoFloatAttributeRequest
  end

  # SYNOPSIS
  #   echoDoubleElement(echoDoubleElementRequest)
  #
  # ARGS
  #   echoDoubleElementRequest EchoDoubleElement - {http://www.w3.org/2002/ws/databinding/examples/6/09/}echoDoubleElement
  #
  # RETURNS
  #   echoDoubleElementResponse EchoDoubleElement - {http://www.w3.org/2002/ws/databinding/examples/6/09/}echoDoubleElement
  #
  def echoDoubleElement(echoDoubleElementRequest)
    p [echoDoubleElementRequest]
    return echoDoubleElementRequest
  end

  # SYNOPSIS
  #   echoDoubleAttribute(echoDoubleAttributeRequest)
  #
  # ARGS
  #   echoDoubleAttributeRequest EchoDoubleAttribute - {http://www.w3.org/2002/ws/databinding/examples/6/09/}echoDoubleAttribute
  #
  # RETURNS
  #   echoDoubleAttributeResponse EchoDoubleAttribute - {http://www.w3.org/2002/ws/databinding/examples/6/09/}echoDoubleAttribute
  #
  def echoDoubleAttribute(echoDoubleAttributeRequest)
    p [echoDoubleAttributeRequest]
    return echoDoubleAttributeRequest
  end

  # SYNOPSIS
  #   echoDurationElement(echoDurationElementRequest)
  #
  # ARGS
  #   echoDurationElementRequest EchoDurationElement - {http://www.w3.org/2002/ws/databinding/examples/6/09/}echoDurationElement
  #
  # RETURNS
  #   echoDurationElementResponse EchoDurationElement - {http://www.w3.org/2002/ws/databinding/examples/6/09/}echoDurationElement
  #
  def echoDurationElement(echoDurationElementRequest)
    p [echoDurationElementRequest]
    return echoDurationElementRequest
  end

  # SYNOPSIS
  #   echoDurationAttribute(echoDurationAttributeRequest)
  #
  # ARGS
  #   echoDurationAttributeRequest EchoDurationAttribute - {http://www.w3.org/2002/ws/databinding/examples/6/09/}echoDurationAttribute
  #
  # RETURNS
  #   echoDurationAttributeResponse EchoDurationAttribute - {http://www.w3.org/2002/ws/databinding/examples/6/09/}echoDurationAttribute
  #
  def echoDurationAttribute(echoDurationAttributeRequest)
    p [echoDurationAttributeRequest]
    return echoDurationAttributeRequest
  end

  # SYNOPSIS
  #   echoDateTimeElement(echoDateTimeElementRequest)
  #
  # ARGS
  #   echoDateTimeElementRequest EchoDateTimeElement - {http://www.w3.org/2002/ws/databinding/examples/6/09/}echoDateTimeElement
  #
  # RETURNS
  #   echoDateTimeElementResponse EchoDateTimeElement - {http://www.w3.org/2002/ws/databinding/examples/6/09/}echoDateTimeElement
  #
  def echoDateTimeElement(echoDateTimeElementRequest)
    p [echoDateTimeElementRequest]
    return echoDateTimeElementRequest
  end

  # SYNOPSIS
  #   echoDateTimeAttribute(echoDateTimeAttributeRequest)
  #
  # ARGS
  #   echoDateTimeAttributeRequest EchoDateTimeAttribute - {http://www.w3.org/2002/ws/databinding/examples/6/09/}echoDateTimeAttribute
  #
  # RETURNS
  #   echoDateTimeAttributeResponse EchoDateTimeAttribute - {http://www.w3.org/2002/ws/databinding/examples/6/09/}echoDateTimeAttribute
  #
  def echoDateTimeAttribute(echoDateTimeAttributeRequest)
    p [echoDateTimeAttributeRequest]
    return echoDateTimeAttributeRequest
  end

  # SYNOPSIS
  #   echoTimeElement(echoTimeElementRequest)
  #
  # ARGS
  #   echoTimeElementRequest EchoTimeElement - {http://www.w3.org/2002/ws/databinding/examples/6/09/}echoTimeElement
  #
  # RETURNS
  #   echoTimeElementResponse EchoTimeElement - {http://www.w3.org/2002/ws/databinding/examples/6/09/}echoTimeElement
  #
  def echoTimeElement(echoTimeElementRequest)
    p [echoTimeElementRequest]
    return echoTimeElementRequest
  end

  # SYNOPSIS
  #   echoTimeAttribute(echoTimeAttributeRequest)
  #
  # ARGS
  #   echoTimeAttributeRequest EchoTimeAttribute - {http://www.w3.org/2002/ws/databinding/examples/6/09/}echoTimeAttribute
  #
  # RETURNS
  #   echoTimeAttributeResponse EchoTimeAttribute - {http://www.w3.org/2002/ws/databinding/examples/6/09/}echoTimeAttribute
  #
  def echoTimeAttribute(echoTimeAttributeRequest)
    p [echoTimeAttributeRequest]
    return echoTimeAttributeRequest
  end

  # SYNOPSIS
  #   echoDateElement(echoDateElementRequest)
  #
  # ARGS
  #   echoDateElementRequest EchoDateElement - {http://www.w3.org/2002/ws/databinding/examples/6/09/}echoDateElement
  #
  # RETURNS
  #   echoDateElementResponse EchoDateElement - {http://www.w3.org/2002/ws/databinding/examples/6/09/}echoDateElement
  #
  def echoDateElement(echoDateElementRequest)
    p [echoDateElementRequest]
    return echoDateElementRequest
  end

  # SYNOPSIS
  #   echoDateAttribute(echoDateAttributeRequest)
  #
  # ARGS
  #   echoDateAttributeRequest EchoDateAttribute - {http://www.w3.org/2002/ws/databinding/examples/6/09/}echoDateAttribute
  #
  # RETURNS
  #   echoDateAttributeResponse EchoDateAttribute - {http://www.w3.org/2002/ws/databinding/examples/6/09/}echoDateAttribute
  #
  def echoDateAttribute(echoDateAttributeRequest)
    p [echoDateAttributeRequest]
    return echoDateAttributeRequest
  end

  # SYNOPSIS
  #   echoGYearMonthElement(echoGYearMonthElementRequest)
  #
  # ARGS
  #   echoGYearMonthElementRequest EchoGYearMonthElement - {http://www.w3.org/2002/ws/databinding/examples/6/09/}echoGYearMonthElement
  #
  # RETURNS
  #   echoGYearMonthElementResponse EchoGYearMonthElement - {http://www.w3.org/2002/ws/databinding/examples/6/09/}echoGYearMonthElement
  #
  def echoGYearMonthElement(echoGYearMonthElementRequest)
    p [echoGYearMonthElementRequest]
    return echoGYearMonthElementRequest
  end

  # SYNOPSIS
  #   echoGYearMonthAttribute(echoGYearMonthAttributeRequest)
  #
  # ARGS
  #   echoGYearMonthAttributeRequest EchoGYearMonthAttribute - {http://www.w3.org/2002/ws/databinding/examples/6/09/}echoGYearMonthAttribute
  #
  # RETURNS
  #   echoGYearMonthAttributeResponse EchoGYearMonthAttribute - {http://www.w3.org/2002/ws/databinding/examples/6/09/}echoGYearMonthAttribute
  #
  def echoGYearMonthAttribute(echoGYearMonthAttributeRequest)
    p [echoGYearMonthAttributeRequest]
    return echoGYearMonthAttributeRequest
  end

  # SYNOPSIS
  #   echoGYearElement(echoGYearElementRequest)
  #
  # ARGS
  #   echoGYearElementRequest EchoGYearElement - {http://www.w3.org/2002/ws/databinding/examples/6/09/}echoGYearElement
  #
  # RETURNS
  #   echoGYearElementResponse EchoGYearElement - {http://www.w3.org/2002/ws/databinding/examples/6/09/}echoGYearElement
  #
  def echoGYearElement(echoGYearElementRequest)
    p [echoGYearElementRequest]
    return echoGYearElementRequest
  end

  # SYNOPSIS
  #   echoGYearAttribute(echoGYearAttributeRequest)
  #
  # ARGS
  #   echoGYearAttributeRequest EchoGYearAttribute - {http://www.w3.org/2002/ws/databinding/examples/6/09/}echoGYearAttribute
  #
  # RETURNS
  #   echoGYearAttributeResponse EchoGYearAttribute - {http://www.w3.org/2002/ws/databinding/examples/6/09/}echoGYearAttribute
  #
  def echoGYearAttribute(echoGYearAttributeRequest)
    p [echoGYearAttributeRequest]
    return echoGYearAttributeRequest
  end

  # SYNOPSIS
  #   echoGMonthDayElement(echoGMonthDayElementRequest)
  #
  # ARGS
  #   echoGMonthDayElementRequest EchoGMonthDayElement - {http://www.w3.org/2002/ws/databinding/examples/6/09/}echoGMonthDayElement
  #
  # RETURNS
  #   echoGMonthDayElementResponse EchoGMonthDayElement - {http://www.w3.org/2002/ws/databinding/examples/6/09/}echoGMonthDayElement
  #
  def echoGMonthDayElement(echoGMonthDayElementRequest)
    p [echoGMonthDayElementRequest]
    return echoGMonthDayElementRequest
  end

  # SYNOPSIS
  #   echoGMonthDayAttribute(echoGMonthDayAttributeRequest)
  #
  # ARGS
  #   echoGMonthDayAttributeRequest EchoGMonthDayAttribute - {http://www.w3.org/2002/ws/databinding/examples/6/09/}echoGMonthDayAttribute
  #
  # RETURNS
  #   echoGMonthDayAttributeResponse EchoGMonthDayAttribute - {http://www.w3.org/2002/ws/databinding/examples/6/09/}echoGMonthDayAttribute
  #
  def echoGMonthDayAttribute(echoGMonthDayAttributeRequest)
    p [echoGMonthDayAttributeRequest]
    return echoGMonthDayAttributeRequest
  end

  # SYNOPSIS
  #   echoGDayElement(echoGDayElementRequest)
  #
  # ARGS
  #   echoGDayElementRequest EchoGDayElement - {http://www.w3.org/2002/ws/databinding/examples/6/09/}echoGDayElement
  #
  # RETURNS
  #   echoGDayElementResponse EchoGDayElement - {http://www.w3.org/2002/ws/databinding/examples/6/09/}echoGDayElement
  #
  def echoGDayElement(echoGDayElementRequest)
    p [echoGDayElementRequest]
    return echoGDayElementRequest
  end

  # SYNOPSIS
  #   echoGDayAttribute(echoGDayAttributeRequest)
  #
  # ARGS
  #   echoGDayAttributeRequest EchoGDayAttribute - {http://www.w3.org/2002/ws/databinding/examples/6/09/}echoGDayAttribute
  #
  # RETURNS
  #   echoGDayAttributeResponse EchoGDayAttribute - {http://www.w3.org/2002/ws/databinding/examples/6/09/}echoGDayAttribute
  #
  def echoGDayAttribute(echoGDayAttributeRequest)
    p [echoGDayAttributeRequest]
    return echoGDayAttributeRequest
  end

  # SYNOPSIS
  #   echoGMonthElement(echoGMonthElementRequest)
  #
  # ARGS
  #   echoGMonthElementRequest EchoGMonthElement - {http://www.w3.org/2002/ws/databinding/examples/6/09/}echoGMonthElement
  #
  # RETURNS
  #   echoGMonthElementResponse EchoGMonthElement - {http://www.w3.org/2002/ws/databinding/examples/6/09/}echoGMonthElement
  #
  def echoGMonthElement(echoGMonthElementRequest)
    p [echoGMonthElementRequest]
    return echoGMonthElementRequest
  end

  # SYNOPSIS
  #   echoGMonthAttribute(echoGMonthAttributeRequest)
  #
  # ARGS
  #   echoGMonthAttributeRequest EchoGMonthAttribute - {http://www.w3.org/2002/ws/databinding/examples/6/09/}echoGMonthAttribute
  #
  # RETURNS
  #   echoGMonthAttributeResponse EchoGMonthAttribute - {http://www.w3.org/2002/ws/databinding/examples/6/09/}echoGMonthAttribute
  #
  def echoGMonthAttribute(echoGMonthAttributeRequest)
    p [echoGMonthAttributeRequest]
    return echoGMonthAttributeRequest
  end

  # SYNOPSIS
  #   echoHexBinaryElement(echoHexBinaryElementRequest)
  #
  # ARGS
  #   echoHexBinaryElementRequest EchoHexBinaryElement - {http://www.w3.org/2002/ws/databinding/examples/6/09/}echoHexBinaryElement
  #
  # RETURNS
  #   echoHexBinaryElementResponse EchoHexBinaryElement - {http://www.w3.org/2002/ws/databinding/examples/6/09/}echoHexBinaryElement
  #
  def echoHexBinaryElement(echoHexBinaryElementRequest)
    p [echoHexBinaryElementRequest]
    return echoHexBinaryElementRequest
  end

  # SYNOPSIS
  #   echoHexBinaryAttribute(echoHexBinaryAttributeRequest)
  #
  # ARGS
  #   echoHexBinaryAttributeRequest EchoHexBinaryAttribute - {http://www.w3.org/2002/ws/databinding/examples/6/09/}echoHexBinaryAttribute
  #
  # RETURNS
  #   echoHexBinaryAttributeResponse EchoHexBinaryAttribute - {http://www.w3.org/2002/ws/databinding/examples/6/09/}echoHexBinaryAttribute
  #
  def echoHexBinaryAttribute(echoHexBinaryAttributeRequest)
    p [echoHexBinaryAttributeRequest]
    return echoHexBinaryAttributeRequest
  end

  # SYNOPSIS
  #   echoBase64BinaryElement(echoBase64BinaryElementRequest)
  #
  # ARGS
  #   echoBase64BinaryElementRequest EchoBase64BinaryElement - {http://www.w3.org/2002/ws/databinding/examples/6/09/}echoBase64BinaryElement
  #
  # RETURNS
  #   echoBase64BinaryElementResponse EchoBase64BinaryElement - {http://www.w3.org/2002/ws/databinding/examples/6/09/}echoBase64BinaryElement
  #
  def echoBase64BinaryElement(echoBase64BinaryElementRequest)
    p [echoBase64BinaryElementRequest]
    return echoBase64BinaryElementRequest
  end

  # SYNOPSIS
  #   echoBase64BinaryAttribute(echoBase64BinaryAttributeRequest)
  #
  # ARGS
  #   echoBase64BinaryAttributeRequest EchoBase64BinaryAttribute - {http://www.w3.org/2002/ws/databinding/examples/6/09/}echoBase64BinaryAttribute
  #
  # RETURNS
  #   echoBase64BinaryAttributeResponse EchoBase64BinaryAttribute - {http://www.w3.org/2002/ws/databinding/examples/6/09/}echoBase64BinaryAttribute
  #
  def echoBase64BinaryAttribute(echoBase64BinaryAttributeRequest)
    p [echoBase64BinaryAttributeRequest]
    return echoBase64BinaryAttributeRequest
  end

  # SYNOPSIS
  #   echoAnyURIElement(echoAnyURIElementRequest)
  #
  # ARGS
  #   echoAnyURIElementRequest EchoAnyURIElement - {http://www.w3.org/2002/ws/databinding/examples/6/09/}echoAnyURIElement
  #
  # RETURNS
  #   echoAnyURIElementResponse EchoAnyURIElement - {http://www.w3.org/2002/ws/databinding/examples/6/09/}echoAnyURIElement
  #
  def echoAnyURIElement(echoAnyURIElementRequest)
    p [echoAnyURIElementRequest]
    return echoAnyURIElementRequest
  end

  # SYNOPSIS
  #   echoAnyURIAttribute(echoAnyURIAttributeRequest)
  #
  # ARGS
  #   echoAnyURIAttributeRequest EchoAnyURIAttribute - {http://www.w3.org/2002/ws/databinding/examples/6/09/}echoAnyURIAttribute
  #
  # RETURNS
  #   echoAnyURIAttributeResponse EchoAnyURIAttribute - {http://www.w3.org/2002/ws/databinding/examples/6/09/}echoAnyURIAttribute
  #
  def echoAnyURIAttribute(echoAnyURIAttributeRequest)
    p [echoAnyURIAttributeRequest]
    return echoAnyURIAttributeRequest
  end

  # SYNOPSIS
  #   echoQNameElement(echoQNameElementRequest)
  #
  # ARGS
  #   echoQNameElementRequest EchoQNameElement - {http://www.w3.org/2002/ws/databinding/examples/6/09/}echoQNameElement
  #
  # RETURNS
  #   echoQNameElementResponse EchoQNameElement - {http://www.w3.org/2002/ws/databinding/examples/6/09/}echoQNameElement
  #
  def echoQNameElement(echoQNameElementRequest)
    p [echoQNameElementRequest]
    return echoQNameElementRequest
  end

  # SYNOPSIS
  #   echoQNameAttribute(echoQNameAttributeRequest)
  #
  # ARGS
  #   echoQNameAttributeRequest EchoQNameAttribute - {http://www.w3.org/2002/ws/databinding/examples/6/09/}echoQNameAttribute
  #
  # RETURNS
  #   echoQNameAttributeResponse EchoQNameAttribute - {http://www.w3.org/2002/ws/databinding/examples/6/09/}echoQNameAttribute
  #
  def echoQNameAttribute(echoQNameAttributeRequest)
    p [echoQNameAttributeRequest]
    return echoQNameAttributeRequest
  end

  # SYNOPSIS
  #   echoNormalizedStringElement(echoNormalizedStringElementRequest)
  #
  # ARGS
  #   echoNormalizedStringElementRequest EchoNormalizedStringElement - {http://www.w3.org/2002/ws/databinding/examples/6/09/}echoNormalizedStringElement
  #
  # RETURNS
  #   echoNormalizedStringElementResponse EchoNormalizedStringElement - {http://www.w3.org/2002/ws/databinding/examples/6/09/}echoNormalizedStringElement
  #
  def echoNormalizedStringElement(echoNormalizedStringElementRequest)
    p [echoNormalizedStringElementRequest]
    return echoNormalizedStringElementRequest
  end

  # SYNOPSIS
  #   echoNormalizedStringAttribute(echoNormalizedStringAttributeRequest)
  #
  # ARGS
  #   echoNormalizedStringAttributeRequest EchoNormalizedStringAttribute - {http://www.w3.org/2002/ws/databinding/examples/6/09/}echoNormalizedStringAttribute
  #
  # RETURNS
  #   echoNormalizedStringAttributeResponse EchoNormalizedStringAttribute - {http://www.w3.org/2002/ws/databinding/examples/6/09/}echoNormalizedStringAttribute
  #
  def echoNormalizedStringAttribute(echoNormalizedStringAttributeRequest)
    p [echoNormalizedStringAttributeRequest]
    return echoNormalizedStringAttributeRequest
  end

  # SYNOPSIS
  #   echoTokenElement(echoTokenElementRequest)
  #
  # ARGS
  #   echoTokenElementRequest EchoTokenElement - {http://www.w3.org/2002/ws/databinding/examples/6/09/}echoTokenElement
  #
  # RETURNS
  #   echoTokenElementResponse EchoTokenElement - {http://www.w3.org/2002/ws/databinding/examples/6/09/}echoTokenElement
  #
  def echoTokenElement(echoTokenElementRequest)
    p [echoTokenElementRequest]
    return echoTokenElementRequest
  end

  # SYNOPSIS
  #   echoTokenAttribute(echoTokenAttributeRequest)
  #
  # ARGS
  #   echoTokenAttributeRequest EchoTokenAttribute - {http://www.w3.org/2002/ws/databinding/examples/6/09/}echoTokenAttribute
  #
  # RETURNS
  #   echoTokenAttributeResponse EchoTokenAttribute - {http://www.w3.org/2002/ws/databinding/examples/6/09/}echoTokenAttribute
  #
  def echoTokenAttribute(echoTokenAttributeRequest)
    p [echoTokenAttributeRequest]
    return echoTokenAttributeRequest
  end

  # SYNOPSIS
  #   echoLanguageElement(echoLanguageElementRequest)
  #
  # ARGS
  #   echoLanguageElementRequest EchoLanguageElement - {http://www.w3.org/2002/ws/databinding/examples/6/09/}echoLanguageElement
  #
  # RETURNS
  #   echoLanguageElementResponse EchoLanguageElement - {http://www.w3.org/2002/ws/databinding/examples/6/09/}echoLanguageElement
  #
  def echoLanguageElement(echoLanguageElementRequest)
    p [echoLanguageElementRequest]
    return echoLanguageElementRequest
  end

  # SYNOPSIS
  #   echoLanguageAttribute(echoLanguageAttributeRequest)
  #
  # ARGS
  #   echoLanguageAttributeRequest EchoLanguageAttribute - {http://www.w3.org/2002/ws/databinding/examples/6/09/}echoLanguageAttribute
  #
  # RETURNS
  #   echoLanguageAttributeResponse EchoLanguageAttribute - {http://www.w3.org/2002/ws/databinding/examples/6/09/}echoLanguageAttribute
  #
  def echoLanguageAttribute(echoLanguageAttributeRequest)
    p [echoLanguageAttributeRequest]
    return echoLanguageAttributeRequest
  end

  # SYNOPSIS
  #   echoNMTOKENElement(echoNMTOKENElementRequest)
  #
  # ARGS
  #   echoNMTOKENElementRequest EchoNMTOKENElement - {http://www.w3.org/2002/ws/databinding/examples/6/09/}echoNMTOKENElement
  #
  # RETURNS
  #   echoNMTOKENElementResponse EchoNMTOKENElement - {http://www.w3.org/2002/ws/databinding/examples/6/09/}echoNMTOKENElement
  #
  def echoNMTOKENElement(echoNMTOKENElementRequest)
    p [echoNMTOKENElementRequest]
    return echoNMTOKENElementRequest
  end

  # SYNOPSIS
  #   echoNMTOKENAttribute(echoNMTOKENAttributeRequest)
  #
  # ARGS
  #   echoNMTOKENAttributeRequest EchoNMTOKENAttribute - {http://www.w3.org/2002/ws/databinding/examples/6/09/}echoNMTOKENAttribute
  #
  # RETURNS
  #   echoNMTOKENAttributeResponse EchoNMTOKENAttribute - {http://www.w3.org/2002/ws/databinding/examples/6/09/}echoNMTOKENAttribute
  #
  def echoNMTOKENAttribute(echoNMTOKENAttributeRequest)
    p [echoNMTOKENAttributeRequest]
    return echoNMTOKENAttributeRequest
  end

  # SYNOPSIS
  #   echoNMTOKENSElement(echoNMTOKENSElementRequest)
  #
  # ARGS
  #   echoNMTOKENSElementRequest EchoNMTOKENSElement - {http://www.w3.org/2002/ws/databinding/examples/6/09/}echoNMTOKENSElement
  #
  # RETURNS
  #   echoNMTOKENSElementResponse EchoNMTOKENSElement - {http://www.w3.org/2002/ws/databinding/examples/6/09/}echoNMTOKENSElement
  #
  def echoNMTOKENSElement(echoNMTOKENSElementRequest)
    p [echoNMTOKENSElementRequest]
    return echoNMTOKENSElementRequest
  end

  # SYNOPSIS
  #   echoNMTOKENSAttribute(echoNMTOKENSAttributeRequest)
  #
  # ARGS
  #   echoNMTOKENSAttributeRequest EchoNMTOKENSAttribute - {http://www.w3.org/2002/ws/databinding/examples/6/09/}echoNMTOKENSAttribute
  #
  # RETURNS
  #   echoNMTOKENSAttributeResponse EchoNMTOKENSAttribute - {http://www.w3.org/2002/ws/databinding/examples/6/09/}echoNMTOKENSAttribute
  #
  def echoNMTOKENSAttribute(echoNMTOKENSAttributeRequest)
    p [echoNMTOKENSAttributeRequest]
    return echoNMTOKENSAttributeRequest
  end

  # SYNOPSIS
  #   echoNameElement(echoNameElementRequest)
  #
  # ARGS
  #   echoNameElementRequest EchoNameElement - {http://www.w3.org/2002/ws/databinding/examples/6/09/}echoNameElement
  #
  # RETURNS
  #   echoNameElementResponse EchoNameElement - {http://www.w3.org/2002/ws/databinding/examples/6/09/}echoNameElement
  #
  def echoNameElement(echoNameElementRequest)
    p [echoNameElementRequest]
    return echoNameElementRequest
  end

  # SYNOPSIS
  #   echoNameAttribute(echoNameAttributeRequest)
  #
  # ARGS
  #   echoNameAttributeRequest EchoNameAttribute - {http://www.w3.org/2002/ws/databinding/examples/6/09/}echoNameAttribute
  #
  # RETURNS
  #   echoNameAttributeResponse EchoNameAttribute - {http://www.w3.org/2002/ws/databinding/examples/6/09/}echoNameAttribute
  #
  def echoNameAttribute(echoNameAttributeRequest)
    p [echoNameAttributeRequest]
    return echoNameAttributeRequest
  end

  # SYNOPSIS
  #   echoNCNameElement(echoNCNameElementRequest)
  #
  # ARGS
  #   echoNCNameElementRequest EchoNCNameElement - {http://www.w3.org/2002/ws/databinding/examples/6/09/}echoNCNameElement
  #
  # RETURNS
  #   echoNCNameElementResponse EchoNCNameElement - {http://www.w3.org/2002/ws/databinding/examples/6/09/}echoNCNameElement
  #
  def echoNCNameElement(echoNCNameElementRequest)
    p [echoNCNameElementRequest]
    return echoNCNameElementRequest
  end

  # SYNOPSIS
  #   echoNCNameAttribute(echoNCNameAttributeRequest)
  #
  # ARGS
  #   echoNCNameAttributeRequest EchoNCNameAttribute - {http://www.w3.org/2002/ws/databinding/examples/6/09/}echoNCNameAttribute
  #
  # RETURNS
  #   echoNCNameAttributeResponse EchoNCNameAttribute - {http://www.w3.org/2002/ws/databinding/examples/6/09/}echoNCNameAttribute
  #
  def echoNCNameAttribute(echoNCNameAttributeRequest)
    p [echoNCNameAttributeRequest]
    return echoNCNameAttributeRequest
  end

  # SYNOPSIS
  #   echoIDElement(echoIDElementRequest)
  #
  # ARGS
  #   echoIDElementRequest EchoIDElement - {http://www.w3.org/2002/ws/databinding/examples/6/09/}echoIDElement
  #
  # RETURNS
  #   echoIDElementResponse EchoIDElement - {http://www.w3.org/2002/ws/databinding/examples/6/09/}echoIDElement
  #
  def echoIDElement(echoIDElementRequest)
    p [echoIDElementRequest]
    return echoIDElementRequest
  end

  # SYNOPSIS
  #   echoIDAttribute(echoIDAttributeRequest)
  #
  # ARGS
  #   echoIDAttributeRequest EchoIDAttribute - {http://www.w3.org/2002/ws/databinding/examples/6/09/}echoIDAttribute
  #
  # RETURNS
  #   echoIDAttributeResponse EchoIDAttribute - {http://www.w3.org/2002/ws/databinding/examples/6/09/}echoIDAttribute
  #
  def echoIDAttribute(echoIDAttributeRequest)
    p [echoIDAttributeRequest]
    return echoIDAttributeRequest
  end

  # SYNOPSIS
  #   echoIDREFElement(echoIDREFElementRequest)
  #
  # ARGS
  #   echoIDREFElementRequest EchoIDREFElement - {http://www.w3.org/2002/ws/databinding/examples/6/09/}echoIDREFElement
  #
  # RETURNS
  #   echoIDREFElementResponse EchoIDREFElement - {http://www.w3.org/2002/ws/databinding/examples/6/09/}echoIDREFElement
  #
  def echoIDREFElement(echoIDREFElementRequest)
    p [echoIDREFElementRequest]
    return echoIDREFElementRequest
  end

  # SYNOPSIS
  #   echoIDREFAttribute(echoIDREFAttributeRequest)
  #
  # ARGS
  #   echoIDREFAttributeRequest EchoIDREFAttribute - {http://www.w3.org/2002/ws/databinding/examples/6/09/}echoIDREFAttribute
  #
  # RETURNS
  #   echoIDREFAttributeResponse EchoIDREFAttribute - {http://www.w3.org/2002/ws/databinding/examples/6/09/}echoIDREFAttribute
  #
  def echoIDREFAttribute(echoIDREFAttributeRequest)
    p [echoIDREFAttributeRequest]
    return echoIDREFAttributeRequest
  end

  # SYNOPSIS
  #   echoIDREFSElement(echoIDREFSElementRequest)
  #
  # ARGS
  #   echoIDREFSElementRequest EchoIDREFSElement - {http://www.w3.org/2002/ws/databinding/examples/6/09/}echoIDREFSElement
  #
  # RETURNS
  #   echoIDREFSElementResponse EchoIDREFSElement - {http://www.w3.org/2002/ws/databinding/examples/6/09/}echoIDREFSElement
  #
  def echoIDREFSElement(echoIDREFSElementRequest)
    p [echoIDREFSElementRequest]
    return echoIDREFSElementRequest
  end

  # SYNOPSIS
  #   echoIDREFSAttribute(echoIDREFSAttributeRequest)
  #
  # ARGS
  #   echoIDREFSAttributeRequest EchoIDREFSAttribute - {http://www.w3.org/2002/ws/databinding/examples/6/09/}echoIDREFSAttribute
  #
  # RETURNS
  #   echoIDREFSAttributeResponse EchoIDREFSAttribute - {http://www.w3.org/2002/ws/databinding/examples/6/09/}echoIDREFSAttribute
  #
  def echoIDREFSAttribute(echoIDREFSAttributeRequest)
    p [echoIDREFSAttributeRequest]
    return echoIDREFSAttributeRequest
  end

  # SYNOPSIS
  #   echoENTITYElement(echoENTITYElementRequest)
  #
  # ARGS
  #   echoENTITYElementRequest EchoENTITYElement - {http://www.w3.org/2002/ws/databinding/examples/6/09/}echoENTITYElement
  #
  # RETURNS
  #   echoENTITYElementResponse EchoENTITYElement - {http://www.w3.org/2002/ws/databinding/examples/6/09/}echoENTITYElement
  #
  def echoENTITYElement(echoENTITYElementRequest)
    p [echoENTITYElementRequest]
    return echoENTITYElementRequest
  end

  # SYNOPSIS
  #   echoENTITYAttribute(echoENTITYAttributeRequest)
  #
  # ARGS
  #   echoENTITYAttributeRequest EchoENTITYAttribute - {http://www.w3.org/2002/ws/databinding/examples/6/09/}echoENTITYAttribute
  #
  # RETURNS
  #   echoENTITYAttributeResponse EchoENTITYAttribute - {http://www.w3.org/2002/ws/databinding/examples/6/09/}echoENTITYAttribute
  #
  def echoENTITYAttribute(echoENTITYAttributeRequest)
    p [echoENTITYAttributeRequest]
    return echoENTITYAttributeRequest
  end

  # SYNOPSIS
  #   echoENTITIESElement(echoENTITIESElementRequest)
  #
  # ARGS
  #   echoENTITIESElementRequest EchoENTITIESElement - {http://www.w3.org/2002/ws/databinding/examples/6/09/}echoENTITIESElement
  #
  # RETURNS
  #   echoENTITIESElementResponse EchoENTITIESElement - {http://www.w3.org/2002/ws/databinding/examples/6/09/}echoENTITIESElement
  #
  def echoENTITIESElement(echoENTITIESElementRequest)
    p [echoENTITIESElementRequest]
    return echoENTITIESElementRequest
  end

  # SYNOPSIS
  #   echoENTITIESAttribute(echoENTITIESAttributeRequest)
  #
  # ARGS
  #   echoENTITIESAttributeRequest EchoENTITIESAttribute - {http://www.w3.org/2002/ws/databinding/examples/6/09/}echoENTITIESAttribute
  #
  # RETURNS
  #   echoENTITIESAttributeResponse EchoENTITIESAttribute - {http://www.w3.org/2002/ws/databinding/examples/6/09/}echoENTITIESAttribute
  #
  def echoENTITIESAttribute(echoENTITIESAttributeRequest)
    p [echoENTITIESAttributeRequest]
    return echoENTITIESAttributeRequest
  end

  # SYNOPSIS
  #   echoIntegerElement(echoIntegerElementRequest)
  #
  # ARGS
  #   echoIntegerElementRequest EchoIntegerElement - {http://www.w3.org/2002/ws/databinding/examples/6/09/}echoIntegerElement
  #
  # RETURNS
  #   echoIntegerElementResponse EchoIntegerElement - {http://www.w3.org/2002/ws/databinding/examples/6/09/}echoIntegerElement
  #
  def echoIntegerElement(echoIntegerElementRequest)
    p [echoIntegerElementRequest]
    return echoIntegerElementRequest
  end

  # SYNOPSIS
  #   echoIntegerAttribute(echoIntegerAttributeRequest)
  #
  # ARGS
  #   echoIntegerAttributeRequest EchoIntegerAttribute - {http://www.w3.org/2002/ws/databinding/examples/6/09/}echoIntegerAttribute
  #
  # RETURNS
  #   echoIntegerAttributeResponse EchoIntegerAttribute - {http://www.w3.org/2002/ws/databinding/examples/6/09/}echoIntegerAttribute
  #
  def echoIntegerAttribute(echoIntegerAttributeRequest)
    p [echoIntegerAttributeRequest]
    return echoIntegerAttributeRequest
  end

  # SYNOPSIS
  #   echoNonPositiveIntegerElement(echoNonPositiveIntegerElementRequest)
  #
  # ARGS
  #   echoNonPositiveIntegerElementRequest EchoNonPositiveIntegerElement - {http://www.w3.org/2002/ws/databinding/examples/6/09/}echoNonPositiveIntegerElement
  #
  # RETURNS
  #   echoNonPositiveIntegerElementResponse EchoNonPositiveIntegerElement - {http://www.w3.org/2002/ws/databinding/examples/6/09/}echoNonPositiveIntegerElement
  #
  def echoNonPositiveIntegerElement(echoNonPositiveIntegerElementRequest)
    p [echoNonPositiveIntegerElementRequest]
    return echoNonPositiveIntegerElementRequest
  end

  # SYNOPSIS
  #   echoNonPositiveIntegerAttribute(echoNonPositiveIntegerAttributeRequest)
  #
  # ARGS
  #   echoNonPositiveIntegerAttributeRequest EchoNonPositiveIntegerAttribute - {http://www.w3.org/2002/ws/databinding/examples/6/09/}echoNonPositiveIntegerAttribute
  #
  # RETURNS
  #   echoNonPositiveIntegerAttributeResponse EchoNonPositiveIntegerAttribute - {http://www.w3.org/2002/ws/databinding/examples/6/09/}echoNonPositiveIntegerAttribute
  #
  def echoNonPositiveIntegerAttribute(echoNonPositiveIntegerAttributeRequest)
    p [echoNonPositiveIntegerAttributeRequest]
    return echoNonPositiveIntegerAttributeRequest
  end

  # SYNOPSIS
  #   echoNegativeIntegerElement(echoNegativeIntegerElementRequest)
  #
  # ARGS
  #   echoNegativeIntegerElementRequest EchoNegativeIntegerElement - {http://www.w3.org/2002/ws/databinding/examples/6/09/}echoNegativeIntegerElement
  #
  # RETURNS
  #   echoNegativeIntegerElementResponse EchoNegativeIntegerElement - {http://www.w3.org/2002/ws/databinding/examples/6/09/}echoNegativeIntegerElement
  #
  def echoNegativeIntegerElement(echoNegativeIntegerElementRequest)
    p [echoNegativeIntegerElementRequest]
    return echoNegativeIntegerElementRequest
  end

  # SYNOPSIS
  #   echoLongElement(echoLongElementRequest)
  #
  # ARGS
  #   echoLongElementRequest EchoLongElement - {http://www.w3.org/2002/ws/databinding/examples/6/09/}echoLongElement
  #
  # RETURNS
  #   echoLongElementResponse EchoLongElement - {http://www.w3.org/2002/ws/databinding/examples/6/09/}echoLongElement
  #
  def echoLongElement(echoLongElementRequest)
    p [echoLongElementRequest]
    return echoLongElementRequest
  end

  # SYNOPSIS
  #   echoLongAttribute(echoLongAttributeRequest)
  #
  # ARGS
  #   echoLongAttributeRequest EchoLongAttribute - {http://www.w3.org/2002/ws/databinding/examples/6/09/}echoLongAttribute
  #
  # RETURNS
  #   echoLongAttributeResponse EchoLongAttribute - {http://www.w3.org/2002/ws/databinding/examples/6/09/}echoLongAttribute
  #
  def echoLongAttribute(echoLongAttributeRequest)
    p [echoLongAttributeRequest]
    return echoLongAttributeRequest
  end

  # SYNOPSIS
  #   echoIntElement(echoIntElementRequest)
  #
  # ARGS
  #   echoIntElementRequest EchoIntElement - {http://www.w3.org/2002/ws/databinding/examples/6/09/}echoIntElement
  #
  # RETURNS
  #   echoIntElementResponse EchoIntElement - {http://www.w3.org/2002/ws/databinding/examples/6/09/}echoIntElement
  #
  def echoIntElement(echoIntElementRequest)
    p [echoIntElementRequest]
    return echoIntElementRequest
  end

  # SYNOPSIS
  #   echoIntAttribute(echoIntAttributeRequest)
  #
  # ARGS
  #   echoIntAttributeRequest EchoIntAttribute - {http://www.w3.org/2002/ws/databinding/examples/6/09/}echoIntAttribute
  #
  # RETURNS
  #   echoIntAttributeResponse EchoIntAttribute - {http://www.w3.org/2002/ws/databinding/examples/6/09/}echoIntAttribute
  #
  def echoIntAttribute(echoIntAttributeRequest)
    p [echoIntAttributeRequest]
    return echoIntAttributeRequest
  end

  # SYNOPSIS
  #   echoShortElement(echoShortElementRequest)
  #
  # ARGS
  #   echoShortElementRequest EchoShortElement - {http://www.w3.org/2002/ws/databinding/examples/6/09/}echoShortElement
  #
  # RETURNS
  #   echoShortElementResponse EchoShortElement - {http://www.w3.org/2002/ws/databinding/examples/6/09/}echoShortElement
  #
  def echoShortElement(echoShortElementRequest)
    p [echoShortElementRequest]
    return echoShortElementRequest
  end

  # SYNOPSIS
  #   echoShortAttribute(echoShortAttributeRequest)
  #
  # ARGS
  #   echoShortAttributeRequest EchoShortAttribute - {http://www.w3.org/2002/ws/databinding/examples/6/09/}echoShortAttribute
  #
  # RETURNS
  #   echoShortAttributeResponse EchoShortAttribute - {http://www.w3.org/2002/ws/databinding/examples/6/09/}echoShortAttribute
  #
  def echoShortAttribute(echoShortAttributeRequest)
    p [echoShortAttributeRequest]
    return echoShortAttributeRequest
  end

  # SYNOPSIS
  #   echoByteElement(echoByteElementRequest)
  #
  # ARGS
  #   echoByteElementRequest EchoByteElement - {http://www.w3.org/2002/ws/databinding/examples/6/09/}echoByteElement
  #
  # RETURNS
  #   echoByteElementResponse EchoByteElement - {http://www.w3.org/2002/ws/databinding/examples/6/09/}echoByteElement
  #
  def echoByteElement(echoByteElementRequest)
    p [echoByteElementRequest]
    return echoByteElementRequest
  end

  # SYNOPSIS
  #   echoByteAttribute(echoByteAttributeRequest)
  #
  # ARGS
  #   echoByteAttributeRequest EchoByteAttribute - {http://www.w3.org/2002/ws/databinding/examples/6/09/}echoByteAttribute
  #
  # RETURNS
  #   echoByteAttributeResponse EchoByteAttribute - {http://www.w3.org/2002/ws/databinding/examples/6/09/}echoByteAttribute
  #
  def echoByteAttribute(echoByteAttributeRequest)
    p [echoByteAttributeRequest]
    return echoByteAttributeRequest
  end

  # SYNOPSIS
  #   echoNonNegativeIntegerElement(echoNonNegativeIntegerElementRequest)
  #
  # ARGS
  #   echoNonNegativeIntegerElementRequest EchoNonNegativeIntegerElement - {http://www.w3.org/2002/ws/databinding/examples/6/09/}echoNonNegativeIntegerElement
  #
  # RETURNS
  #   echoNonNegativeIntegerElementResponse EchoNonNegativeIntegerElement - {http://www.w3.org/2002/ws/databinding/examples/6/09/}echoNonNegativeIntegerElement
  #
  def echoNonNegativeIntegerElement(echoNonNegativeIntegerElementRequest)
    p [echoNonNegativeIntegerElementRequest]
    return echoNonNegativeIntegerElementRequest
  end

  # SYNOPSIS
  #   echoNonNegativeIntegerAttribute(echoNonNegativeIntegerAttributeRequest)
  #
  # ARGS
  #   echoNonNegativeIntegerAttributeRequest EchoNonNegativeIntegerAttribute - {http://www.w3.org/2002/ws/databinding/examples/6/09/}echoNonNegativeIntegerAttribute
  #
  # RETURNS
  #   echoNonNegativeIntegerAttributeResponse EchoNonNegativeIntegerAttribute - {http://www.w3.org/2002/ws/databinding/examples/6/09/}echoNonNegativeIntegerAttribute
  #
  def echoNonNegativeIntegerAttribute(echoNonNegativeIntegerAttributeRequest)
    p [echoNonNegativeIntegerAttributeRequest]
    return echoNonNegativeIntegerAttributeRequest
  end

  # SYNOPSIS
  #   echoUnsignedLongElement(echoUnsignedLongElementRequest)
  #
  # ARGS
  #   echoUnsignedLongElementRequest EchoUnsignedLongElement - {http://www.w3.org/2002/ws/databinding/examples/6/09/}echoUnsignedLongElement
  #
  # RETURNS
  #   echoUnsignedLongElementResponse EchoUnsignedLongElement - {http://www.w3.org/2002/ws/databinding/examples/6/09/}echoUnsignedLongElement
  #
  def echoUnsignedLongElement(echoUnsignedLongElementRequest)
    p [echoUnsignedLongElementRequest]
    return echoUnsignedLongElementRequest
  end

  # SYNOPSIS
  #   echoUnsignedLongAttribute(echoUnsignedLongAttributeRequest)
  #
  # ARGS
  #   echoUnsignedLongAttributeRequest EchoUnsignedLongAttribute - {http://www.w3.org/2002/ws/databinding/examples/6/09/}echoUnsignedLongAttribute
  #
  # RETURNS
  #   echoUnsignedLongAttributeResponse EchoUnsignedLongAttribute - {http://www.w3.org/2002/ws/databinding/examples/6/09/}echoUnsignedLongAttribute
  #
  def echoUnsignedLongAttribute(echoUnsignedLongAttributeRequest)
    p [echoUnsignedLongAttributeRequest]
    return echoUnsignedLongAttributeRequest
  end

  # SYNOPSIS
  #   echoUnsignedIntElement(echoUnsignedIntElementRequest)
  #
  # ARGS
  #   echoUnsignedIntElementRequest EchoUnsignedIntElement - {http://www.w3.org/2002/ws/databinding/examples/6/09/}echoUnsignedIntElement
  #
  # RETURNS
  #   echoUnsignedIntElementResponse EchoUnsignedIntElement - {http://www.w3.org/2002/ws/databinding/examples/6/09/}echoUnsignedIntElement
  #
  def echoUnsignedIntElement(echoUnsignedIntElementRequest)
    p [echoUnsignedIntElementRequest]
    return echoUnsignedIntElementRequest
  end

  # SYNOPSIS
  #   echoUnsignedIntAttribute(echoUnsignedIntAttributeRequest)
  #
  # ARGS
  #   echoUnsignedIntAttributeRequest EchoUnsignedIntAttribute - {http://www.w3.org/2002/ws/databinding/examples/6/09/}echoUnsignedIntAttribute
  #
  # RETURNS
  #   echoUnsignedIntAttributeResponse EchoUnsignedIntAttribute - {http://www.w3.org/2002/ws/databinding/examples/6/09/}echoUnsignedIntAttribute
  #
  def echoUnsignedIntAttribute(echoUnsignedIntAttributeRequest)
    p [echoUnsignedIntAttributeRequest]
    return echoUnsignedIntAttributeRequest
  end

  # SYNOPSIS
  #   echoUnsignedShortElement(echoUnsignedShortElementRequest)
  #
  # ARGS
  #   echoUnsignedShortElementRequest EchoUnsignedShortElement - {http://www.w3.org/2002/ws/databinding/examples/6/09/}echoUnsignedShortElement
  #
  # RETURNS
  #   echoUnsignedShortElementResponse EchoUnsignedShortElement - {http://www.w3.org/2002/ws/databinding/examples/6/09/}echoUnsignedShortElement
  #
  def echoUnsignedShortElement(echoUnsignedShortElementRequest)
    p [echoUnsignedShortElementRequest]
    return echoUnsignedShortElementRequest
  end

  # SYNOPSIS
  #   echoUnsignedShortAttribute(echoUnsignedShortAttributeRequest)
  #
  # ARGS
  #   echoUnsignedShortAttributeRequest EchoUnsignedShortAttribute - {http://www.w3.org/2002/ws/databinding/examples/6/09/}echoUnsignedShortAttribute
  #
  # RETURNS
  #   echoUnsignedShortAttributeResponse EchoUnsignedShortAttribute - {http://www.w3.org/2002/ws/databinding/examples/6/09/}echoUnsignedShortAttribute
  #
  def echoUnsignedShortAttribute(echoUnsignedShortAttributeRequest)
    p [echoUnsignedShortAttributeRequest]
    return echoUnsignedShortAttributeRequest
  end

  # SYNOPSIS
  #   echoNegativeIntegerAttribute(echoNegativeIntegerAttributeRequest)
  #
  # ARGS
  #   echoNegativeIntegerAttributeRequest EchoNegativeIntegerAttribute - {http://www.w3.org/2002/ws/databinding/examples/6/09/}echoNegativeIntegerAttribute
  #
  # RETURNS
  #   echoNegativeIntegerAttributeResponse EchoNegativeIntegerAttribute - {http://www.w3.org/2002/ws/databinding/examples/6/09/}echoNegativeIntegerAttribute
  #
  def echoNegativeIntegerAttribute(echoNegativeIntegerAttributeRequest)
    p [echoNegativeIntegerAttributeRequest]
    return echoNegativeIntegerAttributeRequest
  end

  # SYNOPSIS
  #   echoUnsignedByteElement(echoUnsignedByteElementRequest)
  #
  # ARGS
  #   echoUnsignedByteElementRequest EchoUnsignedByteElement - {http://www.w3.org/2002/ws/databinding/examples/6/09/}echoUnsignedByteElement
  #
  # RETURNS
  #   echoUnsignedByteElementResponse EchoUnsignedByteElement - {http://www.w3.org/2002/ws/databinding/examples/6/09/}echoUnsignedByteElement
  #
  def echoUnsignedByteElement(echoUnsignedByteElementRequest)
    p [echoUnsignedByteElementRequest]
    return echoUnsignedByteElementRequest
  end

  # SYNOPSIS
  #   echoUnsignedByteAttribute(echoUnsignedByteAttributeRequest)
  #
  # ARGS
  #   echoUnsignedByteAttributeRequest EchoUnsignedByteAttribute - {http://www.w3.org/2002/ws/databinding/examples/6/09/}echoUnsignedByteAttribute
  #
  # RETURNS
  #   echoUnsignedByteAttributeResponse EchoUnsignedByteAttribute - {http://www.w3.org/2002/ws/databinding/examples/6/09/}echoUnsignedByteAttribute
  #
  def echoUnsignedByteAttribute(echoUnsignedByteAttributeRequest)
    p [echoUnsignedByteAttributeRequest]
    return echoUnsignedByteAttributeRequest
  end

  # SYNOPSIS
  #   echoPositiveIntegerElement(echoPositiveIntegerElementRequest)
  #
  # ARGS
  #   echoPositiveIntegerElementRequest EchoPositiveIntegerElement - {http://www.w3.org/2002/ws/databinding/examples/6/09/}echoPositiveIntegerElement
  #
  # RETURNS
  #   echoPositiveIntegerElementResponse EchoPositiveIntegerElement - {http://www.w3.org/2002/ws/databinding/examples/6/09/}echoPositiveIntegerElement
  #
  def echoPositiveIntegerElement(echoPositiveIntegerElementRequest)
    p [echoPositiveIntegerElementRequest]
    return echoPositiveIntegerElementRequest
  end

  # SYNOPSIS
  #   echoPositiveIntegerAttribute(echoPositiveIntegerAttributeRequest)
  #
  # ARGS
  #   echoPositiveIntegerAttributeRequest EchoPositiveIntegerAttribute - {http://www.w3.org/2002/ws/databinding/examples/6/09/}echoPositiveIntegerAttribute
  #
  # RETURNS
  #   echoPositiveIntegerAttributeResponse EchoPositiveIntegerAttribute - {http://www.w3.org/2002/ws/databinding/examples/6/09/}echoPositiveIntegerAttribute
  #
  def echoPositiveIntegerAttribute(echoPositiveIntegerAttributeRequest)
    p [echoPositiveIntegerAttributeRequest]
    return echoPositiveIntegerAttributeRequest
  end

  # SYNOPSIS
  #   echoGlobalSimpleType(echoGlobalSimpleTypeRequest)
  #
  # ARGS
  #   echoGlobalSimpleTypeRequest EchoGlobalSimpleType - {http://www.w3.org/2002/ws/databinding/examples/6/09/}echoGlobalSimpleType
  #
  # RETURNS
  #   echoGlobalSimpleTypeResponse EchoGlobalSimpleType - {http://www.w3.org/2002/ws/databinding/examples/6/09/}echoGlobalSimpleType
  #
  def echoGlobalSimpleType(echoGlobalSimpleTypeRequest)
    p [echoGlobalSimpleTypeRequest]
    return echoGlobalSimpleTypeRequest
  end

  # SYNOPSIS
  #   echoStringEnumerationType(echoStringEnumerationTypeRequest)
  #
  # ARGS
  #   echoStringEnumerationTypeRequest EchoStringEnumerationType - {http://www.w3.org/2002/ws/databinding/examples/6/09/}echoStringEnumerationType
  #
  # RETURNS
  #   echoStringEnumerationTypeResponse EchoStringEnumerationType - {http://www.w3.org/2002/ws/databinding/examples/6/09/}echoStringEnumerationType
  #
  def echoStringEnumerationType(echoStringEnumerationTypeRequest)
    p [echoStringEnumerationTypeRequest]
    return echoStringEnumerationTypeRequest
  end

  # SYNOPSIS
  #   echoNMTOKENEnumerationType(echoNMTOKENEnumerationTypeRequest)
  #
  # ARGS
  #   echoNMTOKENEnumerationTypeRequest EchoNMTOKENEnumerationType - {http://www.w3.org/2002/ws/databinding/examples/6/09/}echoNMTOKENEnumerationType
  #
  # RETURNS
  #   echoNMTOKENEnumerationTypeResponse EchoNMTOKENEnumerationType - {http://www.w3.org/2002/ws/databinding/examples/6/09/}echoNMTOKENEnumerationType
  #
  def echoNMTOKENEnumerationType(echoNMTOKENEnumerationTypeRequest)
    p [echoNMTOKENEnumerationTypeRequest]
    return echoNMTOKENEnumerationTypeRequest
  end

  # SYNOPSIS
  #   echoIntEnumerationType(echoIntEnumerationTypeRequest)
  #
  # ARGS
  #   echoIntEnumerationTypeRequest EchoIntEnumerationType - {http://www.w3.org/2002/ws/databinding/examples/6/09/}echoIntEnumerationType
  #
  # RETURNS
  #   echoIntEnumerationTypeResponse EchoIntEnumerationType - {http://www.w3.org/2002/ws/databinding/examples/6/09/}echoIntEnumerationType
  #
  def echoIntEnumerationType(echoIntEnumerationTypeRequest)
    p [echoIntEnumerationTypeRequest]
    return echoIntEnumerationTypeRequest
  end

  # SYNOPSIS
  #   echoShortEnumerationType(echoShortEnumerationTypeRequest)
  #
  # ARGS
  #   echoShortEnumerationTypeRequest EchoShortEnumerationType - {http://www.w3.org/2002/ws/databinding/examples/6/09/}echoShortEnumerationType
  #
  # RETURNS
  #   echoShortEnumerationTypeResponse EchoShortEnumerationType - {http://www.w3.org/2002/ws/databinding/examples/6/09/}echoShortEnumerationType
  #
  def echoShortEnumerationType(echoShortEnumerationTypeRequest)
    p [echoShortEnumerationTypeRequest]
    return echoShortEnumerationTypeRequest
  end

  # SYNOPSIS
  #   echoLongEnumerationType(echoLongEnumerationTypeRequest)
  #
  # ARGS
  #   echoLongEnumerationTypeRequest EchoLongEnumerationType - {http://www.w3.org/2002/ws/databinding/examples/6/09/}echoLongEnumerationType
  #
  # RETURNS
  #   echoLongEnumerationTypeResponse EchoLongEnumerationType - {http://www.w3.org/2002/ws/databinding/examples/6/09/}echoLongEnumerationType
  #
  def echoLongEnumerationType(echoLongEnumerationTypeRequest)
    p [echoLongEnumerationTypeRequest]
    return echoLongEnumerationTypeRequest
  end

  # SYNOPSIS
  #   echoDoubleEnumerationType(echoDoubleEnumerationTypeRequest)
  #
  # ARGS
  #   echoDoubleEnumerationTypeRequest EchoDoubleEnumerationType - {http://www.w3.org/2002/ws/databinding/examples/6/09/}echoDoubleEnumerationType
  #
  # RETURNS
  #   echoDoubleEnumerationTypeResponse EchoDoubleEnumerationType - {http://www.w3.org/2002/ws/databinding/examples/6/09/}echoDoubleEnumerationType
  #
  def echoDoubleEnumerationType(echoDoubleEnumerationTypeRequest)
    p [echoDoubleEnumerationTypeRequest]
    return echoDoubleEnumerationTypeRequest
  end

  # SYNOPSIS
  #   echoIntegerEnumerationType(echoIntegerEnumerationTypeRequest)
  #
  # ARGS
  #   echoIntegerEnumerationTypeRequest EchoIntegerEnumerationType - {http://www.w3.org/2002/ws/databinding/examples/6/09/}echoIntegerEnumerationType
  #
  # RETURNS
  #   echoIntegerEnumerationTypeResponse EchoIntegerEnumerationType - {http://www.w3.org/2002/ws/databinding/examples/6/09/}echoIntegerEnumerationType
  #
  def echoIntegerEnumerationType(echoIntegerEnumerationTypeRequest)
    p [echoIntegerEnumerationTypeRequest]
    return echoIntegerEnumerationTypeRequest
  end

  # SYNOPSIS
  #   echoDecimalEnumerationType(echoDecimalEnumerationTypeRequest)
  #
  # ARGS
  #   echoDecimalEnumerationTypeRequest EchoDecimalEnumerationType - {http://www.w3.org/2002/ws/databinding/examples/6/09/}echoDecimalEnumerationType
  #
  # RETURNS
  #   echoDecimalEnumerationTypeResponse EchoDecimalEnumerationType - {http://www.w3.org/2002/ws/databinding/examples/6/09/}echoDecimalEnumerationType
  #
  def echoDecimalEnumerationType(echoDecimalEnumerationTypeRequest)
    p [echoDecimalEnumerationTypeRequest]
    return echoDecimalEnumerationTypeRequest
  end

  # SYNOPSIS
  #   echoFloatEnumerationType(echoFloatEnumerationTypeRequest)
  #
  # ARGS
  #   echoFloatEnumerationTypeRequest EchoFloatEnumerationType - {http://www.w3.org/2002/ws/databinding/examples/6/09/}echoFloatEnumerationType
  #
  # RETURNS
  #   echoFloatEnumerationTypeResponse EchoFloatEnumerationType - {http://www.w3.org/2002/ws/databinding/examples/6/09/}echoFloatEnumerationType
  #
  def echoFloatEnumerationType(echoFloatEnumerationTypeRequest)
    p [echoFloatEnumerationTypeRequest]
    return echoFloatEnumerationTypeRequest
  end

  # SYNOPSIS
  #   echoNonNegativeIntegerEnumerationType(echoNonNegativeIntegerEnumerationTypeRequest)
  #
  # ARGS
  #   echoNonNegativeIntegerEnumerationTypeRequest EchoNonNegativeIntegerEnumerationType - {http://www.w3.org/2002/ws/databinding/examples/6/09/}echoNonNegativeIntegerEnumerationType
  #
  # RETURNS
  #   echoNonNegativeIntegerEnumerationTypeResponse EchoNonNegativeIntegerEnumerationType - {http://www.w3.org/2002/ws/databinding/examples/6/09/}echoNonNegativeIntegerEnumerationType
  #
  def echoNonNegativeIntegerEnumerationType(echoNonNegativeIntegerEnumerationTypeRequest)
    p [echoNonNegativeIntegerEnumerationTypeRequest]
    return echoNonNegativeIntegerEnumerationTypeRequest
  end

  # SYNOPSIS
  #   echoPositiveIntegerEnumerationType(echoPositiveIntegerEnumerationTypeRequest)
  #
  # ARGS
  #   echoPositiveIntegerEnumerationTypeRequest EchoPositiveIntegerEnumerationType - {http://www.w3.org/2002/ws/databinding/examples/6/09/}echoPositiveIntegerEnumerationType
  #
  # RETURNS
  #   echoPositiveIntegerEnumerationTypeResponse EchoPositiveIntegerEnumerationType - {http://www.w3.org/2002/ws/databinding/examples/6/09/}echoPositiveIntegerEnumerationType
  #
  def echoPositiveIntegerEnumerationType(echoPositiveIntegerEnumerationTypeRequest)
    p [echoPositiveIntegerEnumerationTypeRequest]
    return echoPositiveIntegerEnumerationTypeRequest
  end

  # SYNOPSIS
  #   echoUnsignedLongEnumerationType(echoUnsignedLongEnumerationTypeRequest)
  #
  # ARGS
  #   echoUnsignedLongEnumerationTypeRequest EchoUnsignedLongEnumerationType - {http://www.w3.org/2002/ws/databinding/examples/6/09/}echoUnsignedLongEnumerationType
  #
  # RETURNS
  #   echoUnsignedLongEnumerationTypeResponse EchoUnsignedLongEnumerationType - {http://www.w3.org/2002/ws/databinding/examples/6/09/}echoUnsignedLongEnumerationType
  #
  def echoUnsignedLongEnumerationType(echoUnsignedLongEnumerationTypeRequest)
    p [echoUnsignedLongEnumerationTypeRequest]
    return echoUnsignedLongEnumerationTypeRequest
  end

  # SYNOPSIS
  #   echoUnsignedIntEnumerationType(echoUnsignedIntEnumerationTypeRequest)
  #
  # ARGS
  #   echoUnsignedIntEnumerationTypeRequest EchoUnsignedIntEnumerationType - {http://www.w3.org/2002/ws/databinding/examples/6/09/}echoUnsignedIntEnumerationType
  #
  # RETURNS
  #   echoUnsignedIntEnumerationTypeResponse EchoUnsignedIntEnumerationType - {http://www.w3.org/2002/ws/databinding/examples/6/09/}echoUnsignedIntEnumerationType
  #
  def echoUnsignedIntEnumerationType(echoUnsignedIntEnumerationTypeRequest)
    p [echoUnsignedIntEnumerationTypeRequest]
    return echoUnsignedIntEnumerationTypeRequest
  end

  # SYNOPSIS
  #   echoUnsignedShortEnumerationType(echoUnsignedShortEnumerationTypeRequest)
  #
  # ARGS
  #   echoUnsignedShortEnumerationTypeRequest EchoUnsignedShortEnumerationType - {http://www.w3.org/2002/ws/databinding/examples/6/09/}echoUnsignedShortEnumerationType
  #
  # RETURNS
  #   echoUnsignedShortEnumerationTypeResponse EchoUnsignedShortEnumerationType - {http://www.w3.org/2002/ws/databinding/examples/6/09/}echoUnsignedShortEnumerationType
  #
  def echoUnsignedShortEnumerationType(echoUnsignedShortEnumerationTypeRequest)
    p [echoUnsignedShortEnumerationTypeRequest]
    return echoUnsignedShortEnumerationTypeRequest
  end

  # SYNOPSIS
  #   echoTokenEnumerationType(echoTokenEnumerationTypeRequest)
  #
  # ARGS
  #   echoTokenEnumerationTypeRequest EchoTokenEnumerationType - {http://www.w3.org/2002/ws/databinding/examples/6/09/}echoTokenEnumerationType
  #
  # RETURNS
  #   echoTokenEnumerationTypeResponse EchoTokenEnumerationType - {http://www.w3.org/2002/ws/databinding/examples/6/09/}echoTokenEnumerationType
  #
  def echoTokenEnumerationType(echoTokenEnumerationTypeRequest)
    p [echoTokenEnumerationTypeRequest]
    return echoTokenEnumerationTypeRequest
  end

  # SYNOPSIS
  #   echoComplexTypeSequence(echoComplexTypeSequenceRequest)
  #
  # ARGS
  #   echoComplexTypeSequenceRequest EchoComplexTypeSequence - {http://www.w3.org/2002/ws/databinding/examples/6/09/}echoComplexTypeSequence
  #
  # RETURNS
  #   echoComplexTypeSequenceResponse EchoComplexTypeSequence - {http://www.w3.org/2002/ws/databinding/examples/6/09/}echoComplexTypeSequence
  #
  def echoComplexTypeSequence(echoComplexTypeSequenceRequest)
    p [echoComplexTypeSequenceRequest]
    return echoComplexTypeSequenceRequest
  end

  # SYNOPSIS
  #   echoComplexTypeAll(echoComplexTypeAllRequest)
  #
  # ARGS
  #   echoComplexTypeAllRequest EchoComplexTypeAll - {http://www.w3.org/2002/ws/databinding/examples/6/09/}echoComplexTypeAll
  #
  # RETURNS
  #   echoComplexTypeAllResponse EchoComplexTypeAll - {http://www.w3.org/2002/ws/databinding/examples/6/09/}echoComplexTypeAll
  #
  def echoComplexTypeAll(echoComplexTypeAllRequest)
    p [echoComplexTypeAllRequest]
    return echoComplexTypeAllRequest
  end

  # SYNOPSIS
  #   echoComplexTypeChoice(echoComplexTypeChoiceRequest)
  #
  # ARGS
  #   echoComplexTypeChoiceRequest EchoComplexTypeChoice - {http://www.w3.org/2002/ws/databinding/examples/6/09/}echoComplexTypeChoice
  #
  # RETURNS
  #   echoComplexTypeChoiceResponse EchoComplexTypeChoice - {http://www.w3.org/2002/ws/databinding/examples/6/09/}echoComplexTypeChoice
  #
  def echoComplexTypeChoice(echoComplexTypeChoiceRequest)
    p [echoComplexTypeChoiceRequest]
    return echoComplexTypeChoiceRequest
  end

  # SYNOPSIS
  #   echoComplexTypeSequenceChoice(echoComplexTypeSequenceChoiceRequest)
  #
  # ARGS
  #   echoComplexTypeSequenceChoiceRequest EchoComplexTypeSequenceChoice - {http://www.w3.org/2002/ws/databinding/examples/6/09/}echoComplexTypeSequenceChoice
  #
  # RETURNS
  #   echoComplexTypeSequenceChoiceResponse EchoComplexTypeSequenceChoice - {http://www.w3.org/2002/ws/databinding/examples/6/09/}echoComplexTypeSequenceChoice
  #
  def echoComplexTypeSequenceChoice(echoComplexTypeSequenceChoiceRequest)
    p [echoComplexTypeSequenceChoiceRequest]
    return echoComplexTypeSequenceChoiceRequest
  end

  # SYNOPSIS
  #   echoElementMinOccurs1(echoElementMinOccurs1Request)
  #
  # ARGS
  #   echoElementMinOccurs1Request EchoElementMinOccurs1 - {http://www.w3.org/2002/ws/databinding/examples/6/09/}echoElementMinOccurs1
  #
  # RETURNS
  #   echoElementMinOccurs1Response EchoElementMinOccurs1 - {http://www.w3.org/2002/ws/databinding/examples/6/09/}echoElementMinOccurs1
  #
  def echoElementMinOccurs1(echoElementMinOccurs1Request)
    p [echoElementMinOccurs1Request]
    return echoElementMinOccurs1Request
  end

  # SYNOPSIS
  #   echoElementMinOccurs2MaxOccurs2(echoElementMinOccurs2MaxOccurs2Request)
  #
  # ARGS
  #   echoElementMinOccurs2MaxOccurs2Request EchoElementMinOccurs2MaxOccurs2 - {http://www.w3.org/2002/ws/databinding/examples/6/09/}echoElementMinOccurs2MaxOccurs2
  #
  # RETURNS
  #   echoElementMinOccurs2MaxOccurs2Response EchoElementMinOccurs2MaxOccurs2 - {http://www.w3.org/2002/ws/databinding/examples/6/09/}echoElementMinOccurs2MaxOccurs2
  #
  def echoElementMinOccurs2MaxOccurs2(echoElementMinOccurs2MaxOccurs2Request)
    p [echoElementMinOccurs2MaxOccurs2Request]
    return echoElementMinOccurs2MaxOccurs2Request
  end

  # SYNOPSIS
  #   echoElementMinOccurs2orMore(echoElementMinOccurs2orMoreRequest)
  #
  # ARGS
  #   echoElementMinOccurs2orMoreRequest EchoElementMinOccurs2orMore - {http://www.w3.org/2002/ws/databinding/examples/6/09/}echoElementMinOccurs2orMore
  #
  # RETURNS
  #   echoElementMinOccurs2orMoreResponse EchoElementMinOccurs2orMore - {http://www.w3.org/2002/ws/databinding/examples/6/09/}echoElementMinOccurs2orMore
  #
  def echoElementMinOccurs2orMore(echoElementMinOccurs2orMoreRequest)
    p [echoElementMinOccurs2orMoreRequest]
    return echoElementMinOccurs2orMoreRequest
  end

  # SYNOPSIS
  #   echoElementMaxOccurs1(echoElementMaxOccurs1Request)
  #
  # ARGS
  #   echoElementMaxOccurs1Request EchoElementMaxOccurs1 - {http://www.w3.org/2002/ws/databinding/examples/6/09/}echoElementMaxOccurs1
  #
  # RETURNS
  #   echoElementMaxOccurs1Response EchoElementMaxOccurs1 - {http://www.w3.org/2002/ws/databinding/examples/6/09/}echoElementMaxOccurs1
  #
  def echoElementMaxOccurs1(echoElementMaxOccurs1Request)
    p [echoElementMaxOccurs1Request]
    return echoElementMaxOccurs1Request
  end

  # SYNOPSIS
  #   echoElementMaxOccursUnbounded(echoElementMaxOccursUnboundedRequest)
  #
  # ARGS
  #   echoElementMaxOccursUnboundedRequest EchoElementMaxOccursUnbounded - {http://www.w3.org/2002/ws/databinding/examples/6/09/}echoElementMaxOccursUnbounded
  #
  # RETURNS
  #   echoElementMaxOccursUnboundedResponse EchoElementMaxOccursUnbounded - {http://www.w3.org/2002/ws/databinding/examples/6/09/}echoElementMaxOccursUnbounded
  #
  def echoElementMaxOccursUnbounded(echoElementMaxOccursUnboundedRequest)
    p [echoElementMaxOccursUnboundedRequest]
    return echoElementMaxOccursUnboundedRequest
  end

  # SYNOPSIS
  #   echoElementMaxOccursFinite(echoElementMaxOccursFiniteRequest)
  #
  # ARGS
  #   echoElementMaxOccursFiniteRequest EchoElementMaxOccursFinite - {http://www.w3.org/2002/ws/databinding/examples/6/09/}echoElementMaxOccursFinite
  #
  # RETURNS
  #   echoElementMaxOccursFiniteResponse EchoElementMaxOccursFinite - {http://www.w3.org/2002/ws/databinding/examples/6/09/}echoElementMaxOccursFinite
  #
  def echoElementMaxOccursFinite(echoElementMaxOccursFiniteRequest)
    p [echoElementMaxOccursFiniteRequest]
    return echoElementMaxOccursFiniteRequest
  end

  # SYNOPSIS
  #   echoAttributeOptional(echoAttributeOptionalRequest)
  #
  # ARGS
  #   echoAttributeOptionalRequest EchoAttributeOptional - {http://www.w3.org/2002/ws/databinding/examples/6/09/}echoAttributeOptional
  #
  # RETURNS
  #   echoAttributeOptionalResponse EchoAttributeOptional - {http://www.w3.org/2002/ws/databinding/examples/6/09/}echoAttributeOptional
  #
  def echoAttributeOptional(echoAttributeOptionalRequest)
    p [echoAttributeOptionalRequest]
    return echoAttributeOptionalRequest
  end

  # SYNOPSIS
  #   echoAttributeRequired(echoAttributeRequiredRequest)
  #
  # ARGS
  #   echoAttributeRequiredRequest EchoAttributeRequired - {http://www.w3.org/2002/ws/databinding/examples/6/09/}echoAttributeRequired
  #
  # RETURNS
  #   echoAttributeRequiredResponse EchoAttributeRequired - {http://www.w3.org/2002/ws/databinding/examples/6/09/}echoAttributeRequired
  #
  def echoAttributeRequired(echoAttributeRequiredRequest)
    p [echoAttributeRequiredRequest]
    return echoAttributeRequiredRequest
  end

  # SYNOPSIS
  #   echoAttributeFixed(echoAttributeFixedRequest)
  #
  # ARGS
  #   echoAttributeFixedRequest EchoAttributeFixed - {http://www.w3.org/2002/ws/databinding/examples/6/09/}echoAttributeFixed
  #
  # RETURNS
  #   echoAttributeFixedResponse EchoAttributeFixed - {http://www.w3.org/2002/ws/databinding/examples/6/09/}echoAttributeFixed
  #
  def echoAttributeFixed(echoAttributeFixedRequest)
    p [echoAttributeFixedRequest]
    return echoAttributeFixedRequest
  end

  # SYNOPSIS
  #   echoElementMinOccurs0(echoElementMinOccurs0Request)
  #
  # ARGS
  #   echoElementMinOccurs0Request EchoElementMinOccurs0 - {http://www.w3.org/2002/ws/databinding/examples/6/09/}echoElementMinOccurs0
  #
  # RETURNS
  #   echoElementMinOccurs0Response EchoElementMinOccurs0 - {http://www.w3.org/2002/ws/databinding/examples/6/09/}echoElementMinOccurs0
  #
  def echoElementMinOccurs0(echoElementMinOccurs0Request)
    p [echoElementMinOccurs0Request]
    return echoElementMinOccurs0Request
  end

  # SYNOPSIS
  #   echoNillableElement(echoNillableElementRequest)
  #
  # ARGS
  #   echoNillableElementRequest EchoNillableElement - {http://www.w3.org/2002/ws/databinding/examples/6/09/}echoNillableElement
  #
  # RETURNS
  #   echoNillableElementResponse EchoNillableElement - {http://www.w3.org/2002/ws/databinding/examples/6/09/}echoNillableElement
  #
  def echoNillableElement(echoNillableElementRequest)
    p [echoNillableElementRequest]
    return echoNillableElementRequest
  end

  # SYNOPSIS
  #   echoNillableOptionalElement(echoNillableOptionalElementRequest)
  #
  # ARGS
  #   echoNillableOptionalElementRequest EchoNillableOptionalElement - {http://www.w3.org/2002/ws/databinding/examples/6/09/}echoNillableOptionalElement
  #
  # RETURNS
  #   echoNillableOptionalElementResponse EchoNillableOptionalElement - {http://www.w3.org/2002/ws/databinding/examples/6/09/}echoNillableOptionalElement
  #
  def echoNillableOptionalElement(echoNillableOptionalElementRequest)
    p [echoNillableOptionalElementRequest]
    return echoNillableOptionalElementRequest
  end

  # SYNOPSIS
  #   echoUnionMemberTypes(echoUnionMemberTypesRequest)
  #
  # ARGS
  #   echoUnionMemberTypesRequest EchoUnionMemberTypes - {http://www.w3.org/2002/ws/databinding/examples/6/09/}echoUnionMemberTypes
  #
  # RETURNS
  #   echoUnionMemberTypesResponse EchoUnionMemberTypes - {http://www.w3.org/2002/ws/databinding/examples/6/09/}echoUnionMemberTypes
  #
  def echoUnionMemberTypes(echoUnionMemberTypesRequest)
    p [echoUnionMemberTypesRequest]
    return echoUnionMemberTypesRequest
  end

  # SYNOPSIS
  #   echoNullEnumerationType(echoNullEnumerationTypeRequest)
  #
  # ARGS
  #   echoNullEnumerationTypeRequest EchoNullEnumerationType - {http://www.w3.org/2002/ws/databinding/examples/6/09/}echoNullEnumerationType
  #
  # RETURNS
  #   echoNullEnumerationTypeResponse EchoNullEnumerationType - {http://www.w3.org/2002/ws/databinding/examples/6/09/}echoNullEnumerationType
  #
  def echoNullEnumerationType(echoNullEnumerationTypeRequest)
    p [echoNullEnumerationTypeRequest]
    return echoNullEnumerationTypeRequest
  end

  # SYNOPSIS
  #   echoElementEmptyComplexType(echoElementEmptyComplexTypeRequest)
  #
  # ARGS
  #   echoElementEmptyComplexTypeRequest EchoElementEmptyComplexType - {http://www.w3.org/2002/ws/databinding/examples/6/09/}echoElementEmptyComplexType
  #
  # RETURNS
  #   echoElementEmptyComplexTypeResponse EchoElementEmptyComplexType - {http://www.w3.org/2002/ws/databinding/examples/6/09/}echoElementEmptyComplexType
  #
  def echoElementEmptyComplexType(echoElementEmptyComplexTypeRequest)
    p [echoElementEmptyComplexTypeRequest]
    return echoElementEmptyComplexTypeRequest
  end

  # SYNOPSIS
  #   echoElementEmptySequence(echoElementEmptySequenceRequest)
  #
  # ARGS
  #   echoElementEmptySequenceRequest EchoElementEmptySequence - {http://www.w3.org/2002/ws/databinding/examples/6/09/}echoElementEmptySequence
  #
  # RETURNS
  #   echoElementEmptySequenceResponse EchoElementEmptySequence - {http://www.w3.org/2002/ws/databinding/examples/6/09/}echoElementEmptySequence
  #
  def echoElementEmptySequence(echoElementEmptySequenceRequest)
    p [echoElementEmptySequenceRequest]
    return echoElementEmptySequenceRequest
  end

  # SYNOPSIS
  #   echoGlobalElementSequence(echoGlobalElementSequenceRequest)
  #
  # ARGS
  #   echoGlobalElementSequenceRequest EchoGlobalElementSequence - {http://www.w3.org/2002/ws/databinding/examples/6/09/}echoGlobalElementSequence
  #
  # RETURNS
  #   echoGlobalElementSequenceResponse EchoGlobalElementSequence - {http://www.w3.org/2002/ws/databinding/examples/6/09/}echoGlobalElementSequence
  #
  def echoGlobalElementSequence(echoGlobalElementSequenceRequest)
    p [echoGlobalElementSequenceRequest]
    return echoGlobalElementSequenceRequest
  end

  # SYNOPSIS
  #   echoSequenceElementList(echoSequenceElementListRequest)
  #
  # ARGS
  #   echoSequenceElementListRequest EchoSequenceElementList - {http://www.w3.org/2002/ws/databinding/examples/6/09/}echoSequenceElementList
  #
  # RETURNS
  #   echoSequenceElementListResponse EchoSequenceElementList - {http://www.w3.org/2002/ws/databinding/examples/6/09/}echoSequenceElementList
  #
  def echoSequenceElementList(echoSequenceElementListRequest)
    p [echoSequenceElementListRequest]
    return echoSequenceElementListRequest
  end

  # SYNOPSIS
  #   echoNestedSequenceElementList(echoNestedSequenceElementListRequest)
  #
  # ARGS
  #   echoNestedSequenceElementListRequest EchoNestedSequenceElementList - {http://www.w3.org/2002/ws/databinding/examples/6/09/}echoNestedSequenceElementList
  #
  # RETURNS
  #   echoNestedSequenceElementListResponse EchoNestedSequenceElementList - {http://www.w3.org/2002/ws/databinding/examples/6/09/}echoNestedSequenceElementList
  #
  def echoNestedSequenceElementList(echoNestedSequenceElementListRequest)
    p [echoNestedSequenceElementListRequest]
    return echoNestedSequenceElementListRequest
  end

  # SYNOPSIS
  #   echoMixedContentType(echoMixedContentTypeRequest)
  #
  # ARGS
  #   echoMixedContentTypeRequest EchoMixedContentType - {http://www.w3.org/2002/ws/databinding/examples/6/09/}echoMixedContentType
  #
  # RETURNS
  #   echoMixedContentTypeResponse EchoMixedContentType - {http://www.w3.org/2002/ws/databinding/examples/6/09/}echoMixedContentType
  #
  def echoMixedContentType(echoMixedContentTypeRequest)
    p [echoMixedContentTypeRequest]
    return echoMixedContentTypeRequest
  end

  # SYNOPSIS
  #   echoStringSimpleTypePattern(echoStringSimpleTypePatternRequest)
  #
  # ARGS
  #   echoStringSimpleTypePatternRequest EchoStringSimpleTypePattern - {http://www.w3.org/2002/ws/databinding/examples/6/09/}echoStringSimpleTypePattern
  #
  # RETURNS
  #   echoStringSimpleTypePatternResponse EchoStringSimpleTypePattern - {http://www.w3.org/2002/ws/databinding/examples/6/09/}echoStringSimpleTypePattern
  #
  def echoStringSimpleTypePattern(echoStringSimpleTypePatternRequest)
    p [echoStringSimpleTypePatternRequest]
    return echoStringSimpleTypePatternRequest
  end

  # SYNOPSIS
  #   echoIntSimpleTypePattern(echoIntSimpleTypePatternRequest)
  #
  # ARGS
  #   echoIntSimpleTypePatternRequest EchoIntSimpleTypePattern - {http://www.w3.org/2002/ws/databinding/examples/6/09/}echoIntSimpleTypePattern
  #
  # RETURNS
  #   echoIntSimpleTypePatternResponse EchoIntSimpleTypePattern - {http://www.w3.org/2002/ws/databinding/examples/6/09/}echoIntSimpleTypePattern
  #
  def echoIntSimpleTypePattern(echoIntSimpleTypePatternRequest)
    p [echoIntSimpleTypePatternRequest]
    return echoIntSimpleTypePatternRequest
  end

  # SYNOPSIS
  #   echoIntegerSimpleTypePattern(echoIntegerSimpleTypePatternRequest)
  #
  # ARGS
  #   echoIntegerSimpleTypePatternRequest EchoIntegerSimpleTypePattern - {http://www.w3.org/2002/ws/databinding/examples/6/09/}echoIntegerSimpleTypePattern
  #
  # RETURNS
  #   echoIntegerSimpleTypePatternResponse EchoIntegerSimpleTypePattern - {http://www.w3.org/2002/ws/databinding/examples/6/09/}echoIntegerSimpleTypePattern
  #
  def echoIntegerSimpleTypePattern(echoIntegerSimpleTypePatternRequest)
    p [echoIntegerSimpleTypePatternRequest]
    return echoIntegerSimpleTypePatternRequest
  end

  # SYNOPSIS
  #   echoLongSimpleTypePattern(echoLongSimpleTypePatternRequest)
  #
  # ARGS
  #   echoLongSimpleTypePatternRequest EchoLongSimpleTypePattern - {http://www.w3.org/2002/ws/databinding/examples/6/09/}echoLongSimpleTypePattern
  #
  # RETURNS
  #   echoLongSimpleTypePatternResponse EchoLongSimpleTypePattern - {http://www.w3.org/2002/ws/databinding/examples/6/09/}echoLongSimpleTypePattern
  #
  def echoLongSimpleTypePattern(echoLongSimpleTypePatternRequest)
    p [echoLongSimpleTypePatternRequest]
    return echoLongSimpleTypePatternRequest
  end

  # SYNOPSIS
  #   echoDecimalSimpleTypePattern(echoDecimalSimpleTypePatternRequest)
  #
  # ARGS
  #   echoDecimalSimpleTypePatternRequest EchoDecimalSimpleTypePattern - {http://www.w3.org/2002/ws/databinding/examples/6/09/}echoDecimalSimpleTypePattern
  #
  # RETURNS
  #   echoDecimalSimpleTypePatternResponse EchoDecimalSimpleTypePattern - {http://www.w3.org/2002/ws/databinding/examples/6/09/}echoDecimalSimpleTypePattern
  #
  def echoDecimalSimpleTypePattern(echoDecimalSimpleTypePatternRequest)
    p [echoDecimalSimpleTypePatternRequest]
    return echoDecimalSimpleTypePatternRequest
  end

  # SYNOPSIS
  #   echoFloatSimpleTypePattern(echoFloatSimpleTypePatternRequest)
  #
  # ARGS
  #   echoFloatSimpleTypePatternRequest EchoFloatSimpleTypePattern - {http://www.w3.org/2002/ws/databinding/examples/6/09/}echoFloatSimpleTypePattern
  #
  # RETURNS
  #   echoFloatSimpleTypePatternResponse EchoFloatSimpleTypePattern - {http://www.w3.org/2002/ws/databinding/examples/6/09/}echoFloatSimpleTypePattern
  #
  def echoFloatSimpleTypePattern(echoFloatSimpleTypePatternRequest)
    p [echoFloatSimpleTypePatternRequest]
    return echoFloatSimpleTypePatternRequest
  end

  # SYNOPSIS
  #   echoDoubleSimpleTypePattern(echoDoubleSimpleTypePatternRequest)
  #
  # ARGS
  #   echoDoubleSimpleTypePatternRequest EchoDoubleSimpleTypePattern - {http://www.w3.org/2002/ws/databinding/examples/6/09/}echoDoubleSimpleTypePattern
  #
  # RETURNS
  #   echoDoubleSimpleTypePatternResponse EchoDoubleSimpleTypePattern - {http://www.w3.org/2002/ws/databinding/examples/6/09/}echoDoubleSimpleTypePattern
  #
  def echoDoubleSimpleTypePattern(echoDoubleSimpleTypePatternRequest)
    p [echoDoubleSimpleTypePatternRequest]
    return echoDoubleSimpleTypePatternRequest
  end

  # SYNOPSIS
  #   echoShortSimpleTypePattern(echoShortSimpleTypePatternRequest)
  #
  # ARGS
  #   echoShortSimpleTypePatternRequest EchoShortSimpleTypePattern - {http://www.w3.org/2002/ws/databinding/examples/6/09/}echoShortSimpleTypePattern
  #
  # RETURNS
  #   echoShortSimpleTypePatternResponse EchoShortSimpleTypePattern - {http://www.w3.org/2002/ws/databinding/examples/6/09/}echoShortSimpleTypePattern
  #
  def echoShortSimpleTypePattern(echoShortSimpleTypePatternRequest)
    p [echoShortSimpleTypePatternRequest]
    return echoShortSimpleTypePatternRequest
  end

  # SYNOPSIS
  #   echoNonNegativeIntegerSimpleTypePattern(echoNonNegativeIntegerSimpleTypePatternRequest)
  #
  # ARGS
  #   echoNonNegativeIntegerSimpleTypePatternRequest EchoNonNegativeIntegerSimpleTypePattern - {http://www.w3.org/2002/ws/databinding/examples/6/09/}echoNonNegativeIntegerSimpleTypePattern
  #
  # RETURNS
  #   echoNonNegativeIntegerSimpleTypePatternResponse EchoNonNegativeIntegerSimpleTypePattern - {http://www.w3.org/2002/ws/databinding/examples/6/09/}echoNonNegativeIntegerSimpleTypePattern
  #
  def echoNonNegativeIntegerSimpleTypePattern(echoNonNegativeIntegerSimpleTypePatternRequest)
    p [echoNonNegativeIntegerSimpleTypePatternRequest]
    return echoNonNegativeIntegerSimpleTypePatternRequest
  end

  # SYNOPSIS
  #   echoPositiveIntegerSimpleTypePattern(echoPositiveIntegerSimpleTypePatternRequest)
  #
  # ARGS
  #   echoPositiveIntegerSimpleTypePatternRequest EchoPositiveIntegerSimpleTypePattern - {http://www.w3.org/2002/ws/databinding/examples/6/09/}echoPositiveIntegerSimpleTypePattern
  #
  # RETURNS
  #   echoPositiveIntegerSimpleTypePatternResponse EchoPositiveIntegerSimpleTypePattern - {http://www.w3.org/2002/ws/databinding/examples/6/09/}echoPositiveIntegerSimpleTypePattern
  #
  def echoPositiveIntegerSimpleTypePattern(echoPositiveIntegerSimpleTypePatternRequest)
    p [echoPositiveIntegerSimpleTypePatternRequest]
    return echoPositiveIntegerSimpleTypePatternRequest
  end

  # SYNOPSIS
  #   echoUnsignedLongSimpleTypePattern(echoUnsignedLongSimpleTypePatternRequest)
  #
  # ARGS
  #   echoUnsignedLongSimpleTypePatternRequest EchoUnsignedLongSimpleTypePattern - {http://www.w3.org/2002/ws/databinding/examples/6/09/}echoUnsignedLongSimpleTypePattern
  #
  # RETURNS
  #   echoUnsignedLongSimpleTypePatternResponse EchoUnsignedLongSimpleTypePattern - {http://www.w3.org/2002/ws/databinding/examples/6/09/}echoUnsignedLongSimpleTypePattern
  #
  def echoUnsignedLongSimpleTypePattern(echoUnsignedLongSimpleTypePatternRequest)
    p [echoUnsignedLongSimpleTypePatternRequest]
    return echoUnsignedLongSimpleTypePatternRequest
  end

  # SYNOPSIS
  #   echoUnsignedIntSimpleTypePattern(echoUnsignedIntSimpleTypePatternRequest)
  #
  # ARGS
  #   echoUnsignedIntSimpleTypePatternRequest EchoUnsignedIntSimpleTypePattern - {http://www.w3.org/2002/ws/databinding/examples/6/09/}echoUnsignedIntSimpleTypePattern
  #
  # RETURNS
  #   echoUnsignedIntSimpleTypePatternResponse EchoUnsignedIntSimpleTypePattern - {http://www.w3.org/2002/ws/databinding/examples/6/09/}echoUnsignedIntSimpleTypePattern
  #
  def echoUnsignedIntSimpleTypePattern(echoUnsignedIntSimpleTypePatternRequest)
    p [echoUnsignedIntSimpleTypePatternRequest]
    return echoUnsignedIntSimpleTypePatternRequest
  end

  # SYNOPSIS
  #   echoUnsignedShortSimpleTypePattern(echoUnsignedShortSimpleTypePatternRequest)
  #
  # ARGS
  #   echoUnsignedShortSimpleTypePatternRequest EchoUnsignedShortSimpleTypePattern - {http://www.w3.org/2002/ws/databinding/examples/6/09/}echoUnsignedShortSimpleTypePattern
  #
  # RETURNS
  #   echoUnsignedShortSimpleTypePatternResponse EchoUnsignedShortSimpleTypePattern - {http://www.w3.org/2002/ws/databinding/examples/6/09/}echoUnsignedShortSimpleTypePattern
  #
  def echoUnsignedShortSimpleTypePattern(echoUnsignedShortSimpleTypePatternRequest)
    p [echoUnsignedShortSimpleTypePatternRequest]
    return echoUnsignedShortSimpleTypePatternRequest
  end

  # SYNOPSIS
  #   echoDateSimpleTypePattern(echoDateSimpleTypePatternRequest)
  #
  # ARGS
  #   echoDateSimpleTypePatternRequest EchoDateSimpleTypePattern - {http://www.w3.org/2002/ws/databinding/examples/6/09/}echoDateSimpleTypePattern
  #
  # RETURNS
  #   echoDateSimpleTypePatternResponse EchoDateSimpleTypePattern - {http://www.w3.org/2002/ws/databinding/examples/6/09/}echoDateSimpleTypePattern
  #
  def echoDateSimpleTypePattern(echoDateSimpleTypePatternRequest)
    p [echoDateSimpleTypePatternRequest]
    return echoDateSimpleTypePatternRequest
  end

  # SYNOPSIS
  #   echoRestrictedMinInclusive(echoRestrictedMinInclusiveRequest)
  #
  # ARGS
  #   echoRestrictedMinInclusiveRequest EchoRestrictedMinInclusive - {http://www.w3.org/2002/ws/databinding/examples/6/09/}echoRestrictedMinInclusive
  #
  # RETURNS
  #   echoRestrictedMinInclusiveResponse EchoRestrictedMinInclusive - {http://www.w3.org/2002/ws/databinding/examples/6/09/}echoRestrictedMinInclusive
  #
  def echoRestrictedMinInclusive(echoRestrictedMinInclusiveRequest)
    p [echoRestrictedMinInclusiveRequest]
    return echoRestrictedMinInclusiveRequest
  end

  # SYNOPSIS
  #   echoRestrictedMaxInclusive(echoRestrictedMaxInclusiveRequest)
  #
  # ARGS
  #   echoRestrictedMaxInclusiveRequest EchoRestrictedMaxInclusive - {http://www.w3.org/2002/ws/databinding/examples/6/09/}echoRestrictedMaxInclusive
  #
  # RETURNS
  #   echoRestrictedMaxInclusiveResponse EchoRestrictedMaxInclusive - {http://www.w3.org/2002/ws/databinding/examples/6/09/}echoRestrictedMaxInclusive
  #
  def echoRestrictedMaxInclusive(echoRestrictedMaxInclusiveRequest)
    p [echoRestrictedMaxInclusiveRequest]
    return echoRestrictedMaxInclusiveRequest
  end

  # SYNOPSIS
  #   echoRestrictedLength(echoRestrictedLengthRequest)
  #
  # ARGS
  #   echoRestrictedLengthRequest EchoRestrictedLength - {http://www.w3.org/2002/ws/databinding/examples/6/09/}echoRestrictedLength
  #
  # RETURNS
  #   echoRestrictedLengthResponse EchoRestrictedLength - {http://www.w3.org/2002/ws/databinding/examples/6/09/}echoRestrictedLength
  #
  def echoRestrictedLength(echoRestrictedLengthRequest)
    p [echoRestrictedLengthRequest]
    return echoRestrictedLengthRequest
  end

  # SYNOPSIS
  #   echoRestrictedMaxLength(echoRestrictedMaxLengthRequest)
  #
  # ARGS
  #   echoRestrictedMaxLengthRequest EchoRestrictedMaxLength - {http://www.w3.org/2002/ws/databinding/examples/6/09/}echoRestrictedMaxLength
  #
  # RETURNS
  #   echoRestrictedMaxLengthResponse EchoRestrictedMaxLength - {http://www.w3.org/2002/ws/databinding/examples/6/09/}echoRestrictedMaxLength
  #
  def echoRestrictedMaxLength(echoRestrictedMaxLengthRequest)
    p [echoRestrictedMaxLengthRequest]
    return echoRestrictedMaxLengthRequest
  end

  # SYNOPSIS
  #   echoRestrictedMinLength(echoRestrictedMinLengthRequest)
  #
  # ARGS
  #   echoRestrictedMinLengthRequest EchoRestrictedMinLength - {http://www.w3.org/2002/ws/databinding/examples/6/09/}echoRestrictedMinLength
  #
  # RETURNS
  #   echoRestrictedMinLengthResponse EchoRestrictedMinLength - {http://www.w3.org/2002/ws/databinding/examples/6/09/}echoRestrictedMinLength
  #
  def echoRestrictedMinLength(echoRestrictedMinLengthRequest)
    p [echoRestrictedMinLengthRequest]
    return echoRestrictedMinLengthRequest
  end

  # SYNOPSIS
  #   echoElementReference(echoElementReferenceRequest)
  #
  # ARGS
  #   echoElementReferenceRequest EchoElementReference - {http://www.w3.org/2002/ws/databinding/examples/6/09/}echoElementReference
  #
  # RETURNS
  #   echoElementReferenceResponse EchoElementReference - {http://www.w3.org/2002/ws/databinding/examples/6/09/}echoElementReference
  #
  def echoElementReference(echoElementReferenceRequest)
    p [echoElementReferenceRequest]
    return echoElementReferenceRequest
  end

  # SYNOPSIS
  #   echoAttributeReference(echoAttributeReferenceRequest)
  #
  # ARGS
  #   echoAttributeReferenceRequest EchoAttributeReference - {http://www.w3.org/2002/ws/databinding/examples/6/09/}echoAttributeReference
  #
  # RETURNS
  #   echoAttributeReferenceResponse EchoAttributeReference - {http://www.w3.org/2002/ws/databinding/examples/6/09/}echoAttributeReference
  #
  def echoAttributeReference(echoAttributeReferenceRequest)
    p [echoAttributeReferenceRequest]
    return echoAttributeReferenceRequest
  end

  # SYNOPSIS
  #   echoAttributeElementNameClash(echoAttributeElementNameClashRequest)
  #
  # ARGS
  #   echoAttributeElementNameClashRequest EchoAttributeElementNameClash - {http://www.w3.org/2002/ws/databinding/examples/6/09/}echoAttributeElementNameClash
  #
  # RETURNS
  #   echoAttributeElementNameClashResponse EchoAttributeElementNameClash - {http://www.w3.org/2002/ws/databinding/examples/6/09/}echoAttributeElementNameClash
  #
  def echoAttributeElementNameClash(echoAttributeElementNameClashRequest)
    p [echoAttributeElementNameClashRequest]
    return echoAttributeElementNameClashRequest
  end

  # SYNOPSIS
  #   echoExtendedSequenceStrict(echoExtendedSequenceStrictRequest)
  #
  # ARGS
  #   echoExtendedSequenceStrictRequest EchoExtendedSequenceStrict - {http://www.w3.org/2002/ws/databinding/examples/6/09/}echoExtendedSequenceStrict
  #
  # RETURNS
  #   echoExtendedSequenceStrictResponse EchoExtendedSequenceStrict - {http://www.w3.org/2002/ws/databinding/examples/6/09/}echoExtendedSequenceStrict
  #
  def echoExtendedSequenceStrict(echoExtendedSequenceStrictRequest)
    p [echoExtendedSequenceStrictRequest]
    return echoExtendedSequenceStrictRequest
  end

  # SYNOPSIS
  #   echoExtendedSequenceLax(echoExtendedSequenceLaxRequest)
  #
  # ARGS
  #   echoExtendedSequenceLaxRequest EchoExtendedSequenceLax - {http://www.w3.org/2002/ws/databinding/examples/6/09/}echoExtendedSequenceLax
  #
  # RETURNS
  #   echoExtendedSequenceLaxResponse EchoExtendedSequenceLax - {http://www.w3.org/2002/ws/databinding/examples/6/09/}echoExtendedSequenceLax
  #
  def echoExtendedSequenceLax(echoExtendedSequenceLaxRequest)
    p [echoExtendedSequenceLaxRequest]
    return echoExtendedSequenceLaxRequest
  end

  # SYNOPSIS
  #   echoExtendedSequenceSkip(echoExtendedSequenceSkipRequest)
  #
  # ARGS
  #   echoExtendedSequenceSkipRequest EchoExtendedSequenceSkip - {http://www.w3.org/2002/ws/databinding/examples/6/09/}echoExtendedSequenceSkip
  #
  # RETURNS
  #   echoExtendedSequenceSkipResponse EchoExtendedSequenceSkip - {http://www.w3.org/2002/ws/databinding/examples/6/09/}echoExtendedSequenceSkip
  #
  def echoExtendedSequenceSkip(echoExtendedSequenceSkipRequest)
    p [echoExtendedSequenceSkipRequest]
    return echoExtendedSequenceSkipRequest
  end

  # SYNOPSIS
  #   echoElementTypeDefaultNamespace(echoElementTypeDefaultNamespaceRequest)
  #
  # ARGS
  #   echoElementTypeDefaultNamespaceRequest EchoElementTypeDefaultNamespace - {http://www.w3.org/2002/ws/databinding/examples/6/09/}echoElementTypeDefaultNamespace
  #
  # RETURNS
  #   echoElementTypeDefaultNamespaceResponse EchoElementTypeDefaultNamespace - {http://www.w3.org/2002/ws/databinding/examples/6/09/}echoElementTypeDefaultNamespace
  #
  def echoElementTypeDefaultNamespace(echoElementTypeDefaultNamespaceRequest)
    p [echoElementTypeDefaultNamespaceRequest]
    return echoElementTypeDefaultNamespaceRequest
  end

  # SYNOPSIS
  #   echoBareVector(echoBareVectorRequest)
  #
  # ARGS
  #   echoBareVectorRequest EchoBareVector - {http://www.w3.org/2002/ws/databinding/examples/6/09/}echoBareVector
  #
  # RETURNS
  #   echoBareVectorResponse EchoBareVector - {http://www.w3.org/2002/ws/databinding/examples/6/09/}echoBareVector
  #
  def echoBareVector(echoBareVectorRequest)
    p [echoBareVectorRequest]
    return echoBareVectorRequest
  end

  # SYNOPSIS
  #   echoComplexTypeSequenceExtension(echoComplexTypeSequenceExtensionRequest)
  #
  # ARGS
  #   echoComplexTypeSequenceExtensionRequest EchoComplexTypeSequenceExtension - {http://www.w3.org/2002/ws/databinding/examples/6/09/}echoComplexTypeSequenceExtension
  #
  # RETURNS
  #   echoComplexTypeSequenceExtensionResponse EchoComplexTypeSequenceExtension - {http://www.w3.org/2002/ws/databinding/examples/6/09/}echoComplexTypeSequenceExtension
  #
  def echoComplexTypeSequenceExtension(echoComplexTypeSequenceExtensionRequest)
    p [echoComplexTypeSequenceExtensionRequest]
    return echoComplexTypeSequenceExtensionRequest
  end

  # SYNOPSIS
  #   echoTypeSubstitutionUsingXsiType(echoTypeSubstitutionUsingXsiTypeRequest)
  #
  # ARGS
  #   echoTypeSubstitutionUsingXsiTypeRequest EchoTypeSubstitutionUsingXsiType - {http://www.w3.org/2002/ws/databinding/examples/6/09/}echoTypeSubstitutionUsingXsiType
  #
  # RETURNS
  #   echoTypeSubstitutionUsingXsiTypeResponse EchoTypeSubstitutionUsingXsiType - {http://www.w3.org/2002/ws/databinding/examples/6/09/}echoTypeSubstitutionUsingXsiType
  #
  def echoTypeSubstitutionUsingXsiType(echoTypeSubstitutionUsingXsiTypeRequest)
    p [echoTypeSubstitutionUsingXsiTypeRequest]
    return echoTypeSubstitutionUsingXsiTypeRequest
  end

  # SYNOPSIS
  #   echoSimpleTypeAttributes(echoSimpleTypeAttributesRequest)
  #
  # ARGS
  #   echoSimpleTypeAttributesRequest EchoSimpleTypeAttributes - {http://www.w3.org/2002/ws/databinding/examples/6/09/}echoSimpleTypeAttributes
  #
  # RETURNS
  #   echoSimpleTypeAttributesResponse EchoSimpleTypeAttributes - {http://www.w3.org/2002/ws/databinding/examples/6/09/}echoSimpleTypeAttributes
  #
  def echoSimpleTypeAttributes(echoSimpleTypeAttributesRequest)
    p [echoSimpleTypeAttributesRequest]
    return echoSimpleTypeAttributesRequest
  end

  # SYNOPSIS
  #   echoExtendedSimpleType(echoExtendedSimpleTypeRequest)
  #
  # ARGS
  #   echoExtendedSimpleTypeRequest EchoExtendedSimpleType - {http://www.w3.org/2002/ws/databinding/examples/6/09/}echoExtendedSimpleType
  #
  # RETURNS
  #   echoExtendedSimpleTypeResponse EchoExtendedSimpleType - {http://www.w3.org/2002/ws/databinding/examples/6/09/}echoExtendedSimpleType
  #
  def echoExtendedSimpleType(echoExtendedSimpleTypeRequest)
    p [echoExtendedSimpleTypeRequest]
    return echoExtendedSimpleTypeRequest
  end

  # SYNOPSIS
  #   echoSequenceMinOccurs1(echoSequenceMinOccurs1Request)
  #
  # ARGS
  #   echoSequenceMinOccurs1Request EchoSequenceMinOccurs1 - {http://www.w3.org/2002/ws/databinding/examples/6/09/}echoSequenceMinOccurs1
  #
  # RETURNS
  #   echoSequenceMinOccurs1Response EchoSequenceMinOccurs1 - {http://www.w3.org/2002/ws/databinding/examples/6/09/}echoSequenceMinOccurs1
  #
  def echoSequenceMinOccurs1(echoSequenceMinOccurs1Request)
    p [echoSequenceMinOccurs1Request]
    return echoSequenceMinOccurs1Request
  end

  # SYNOPSIS
  #   echoSequenceMinOccursFinite(echoSequenceMinOccursFiniteRequest)
  #
  # ARGS
  #   echoSequenceMinOccursFiniteRequest EchoSequenceMinOccursFinite - {http://www.w3.org/2002/ws/databinding/examples/6/09/}echoSequenceMinOccursFinite
  #
  # RETURNS
  #   echoSequenceMinOccursFiniteResponse EchoSequenceMinOccursFinite - {http://www.w3.org/2002/ws/databinding/examples/6/09/}echoSequenceMinOccursFinite
  #
  def echoSequenceMinOccursFinite(echoSequenceMinOccursFiniteRequest)
    p [echoSequenceMinOccursFiniteRequest]
    return echoSequenceMinOccursFiniteRequest
  end

  # SYNOPSIS
  #   echoSequenceMaxOccurs1(echoSequenceMaxOccurs1Request)
  #
  # ARGS
  #   echoSequenceMaxOccurs1Request EchoSequenceMaxOccurs1 - {http://www.w3.org/2002/ws/databinding/examples/6/09/}echoSequenceMaxOccurs1
  #
  # RETURNS
  #   echoSequenceMaxOccurs1Response EchoSequenceMaxOccurs1 - {http://www.w3.org/2002/ws/databinding/examples/6/09/}echoSequenceMaxOccurs1
  #
  def echoSequenceMaxOccurs1(echoSequenceMaxOccurs1Request)
    p [echoSequenceMaxOccurs1Request]
    return echoSequenceMaxOccurs1Request
  end

  # SYNOPSIS
  #   echoElementMinOccurs0MaxOccursUnbounded(echoElementMinOccurs0MaxOccursUnboundedRequest)
  #
  # ARGS
  #   echoElementMinOccurs0MaxOccursUnboundedRequest EchoElementMinOccurs0MaxOccursUnbounded - {http://www.w3.org/2002/ws/databinding/examples/6/09/}echoElementMinOccurs0MaxOccursUnbounded
  #
  # RETURNS
  #   echoElementMinOccurs0MaxOccursUnboundedResponse EchoElementMinOccurs0MaxOccursUnbounded - {http://www.w3.org/2002/ws/databinding/examples/6/09/}echoElementMinOccurs0MaxOccursUnbounded
  #
  def echoElementMinOccurs0MaxOccursUnbounded(echoElementMinOccurs0MaxOccursUnboundedRequest)
    p [echoElementMinOccurs0MaxOccursUnboundedRequest]
    return echoElementMinOccurs0MaxOccursUnboundedRequest
  end

  # SYNOPSIS
  #   echoSequenceMinOccurs0MaxOccursUnbounded(echoSequenceMinOccurs0MaxOccursUnboundedRequest)
  #
  # ARGS
  #   echoSequenceMinOccurs0MaxOccursUnboundedRequest EchoSequenceMinOccurs0MaxOccursUnbounded - {http://www.w3.org/2002/ws/databinding/examples/6/09/}echoSequenceMinOccurs0MaxOccursUnbounded
  #
  # RETURNS
  #   echoSequenceMinOccurs0MaxOccursUnboundedResponse EchoSequenceMinOccurs0MaxOccursUnbounded - {http://www.w3.org/2002/ws/databinding/examples/6/09/}echoSequenceMinOccurs0MaxOccursUnbounded
  #
  def echoSequenceMinOccurs0MaxOccursUnbounded(echoSequenceMinOccurs0MaxOccursUnboundedRequest)
    p [echoSequenceMinOccurs0MaxOccursUnboundedRequest]
    return echoSequenceMinOccurs0MaxOccursUnboundedRequest
  end

  # SYNOPSIS
  #   echoElementMinOccurs1MaxOccursUnbounded(echoElementMinOccurs1MaxOccursUnboundedRequest)
  #
  # ARGS
  #   echoElementMinOccurs1MaxOccursUnboundedRequest EchoElementMinOccurs1MaxOccursUnbounded - {http://www.w3.org/2002/ws/databinding/examples/6/09/}echoElementMinOccurs1MaxOccursUnbounded
  #
  # RETURNS
  #   echoElementMinOccurs1MaxOccursUnboundedResponse EchoElementMinOccurs1MaxOccursUnbounded - {http://www.w3.org/2002/ws/databinding/examples/6/09/}echoElementMinOccurs1MaxOccursUnbounded
  #
  def echoElementMinOccurs1MaxOccursUnbounded(echoElementMinOccurs1MaxOccursUnboundedRequest)
    p [echoElementMinOccurs1MaxOccursUnboundedRequest]
    return echoElementMinOccurs1MaxOccursUnboundedRequest
  end

  # SYNOPSIS
  #   echoSequenceMinOccurs1MaxOccursUnbounded(echoSequenceMinOccurs1MaxOccursUnboundedRequest)
  #
  # ARGS
  #   echoSequenceMinOccurs1MaxOccursUnboundedRequest EchoSequenceMinOccurs1MaxOccursUnbounded - {http://www.w3.org/2002/ws/databinding/examples/6/09/}echoSequenceMinOccurs1MaxOccursUnbounded
  #
  # RETURNS
  #   echoSequenceMinOccurs1MaxOccursUnboundedResponse EchoSequenceMinOccurs1MaxOccursUnbounded - {http://www.w3.org/2002/ws/databinding/examples/6/09/}echoSequenceMinOccurs1MaxOccursUnbounded
  #
  def echoSequenceMinOccurs1MaxOccursUnbounded(echoSequenceMinOccurs1MaxOccursUnboundedRequest)
    p [echoSequenceMinOccurs1MaxOccursUnboundedRequest]
    return echoSequenceMinOccurs1MaxOccursUnboundedRequest
  end

  # SYNOPSIS
  #   echoSequenceMaxOccursUnbounded(echoSequenceMaxOccursUnboundedRequest)
  #
  # ARGS
  #   echoSequenceMaxOccursUnboundedRequest EchoSequenceMaxOccursUnbounded - {http://www.w3.org/2002/ws/databinding/examples/6/09/}echoSequenceMaxOccursUnbounded
  #
  # RETURNS
  #   echoSequenceMaxOccursUnboundedResponse EchoSequenceMaxOccursUnbounded - {http://www.w3.org/2002/ws/databinding/examples/6/09/}echoSequenceMaxOccursUnbounded
  #
  def echoSequenceMaxOccursUnbounded(echoSequenceMaxOccursUnboundedRequest)
    p [echoSequenceMaxOccursUnboundedRequest]
    return echoSequenceMaxOccursUnboundedRequest
  end

  # SYNOPSIS
  #   echoSequenceMaxOccursFinite(echoSequenceMaxOccursFiniteRequest)
  #
  # ARGS
  #   echoSequenceMaxOccursFiniteRequest EchoSequenceMaxOccursFinite - {http://www.w3.org/2002/ws/databinding/examples/6/09/}echoSequenceMaxOccursFinite
  #
  # RETURNS
  #   echoSequenceMaxOccursFiniteResponse EchoSequenceMaxOccursFinite - {http://www.w3.org/2002/ws/databinding/examples/6/09/}echoSequenceMaxOccursFinite
  #
  def echoSequenceMaxOccursFinite(echoSequenceMaxOccursFiniteRequest)
    p [echoSequenceMaxOccursFiniteRequest]
    return echoSequenceMaxOccursFiniteRequest
  end

  # SYNOPSIS
  #   echoSequenceMinOccurs0(echoSequenceMinOccurs0Request)
  #
  # ARGS
  #   echoSequenceMinOccurs0Request EchoSequenceMinOccurs0 - {http://www.w3.org/2002/ws/databinding/examples/6/09/}echoSequenceMinOccurs0
  #
  # RETURNS
  #   echoSequenceMinOccurs0Response EchoSequenceMinOccurs0 - {http://www.w3.org/2002/ws/databinding/examples/6/09/}echoSequenceMinOccurs0
  #
  def echoSequenceMinOccurs0(echoSequenceMinOccurs0Request)
    p [echoSequenceMinOccurs0Request]
    return echoSequenceMinOccurs0Request
  end

  # SYNOPSIS
  #   echoSequenceSequenceElement(echoSequenceSequenceElementRequest)
  #
  # ARGS
  #   echoSequenceSequenceElementRequest EchoSequenceSequenceElement - {http://www.w3.org/2002/ws/databinding/examples/6/09/}echoSequenceSequenceElement
  #
  # RETURNS
  #   echoSequenceSequenceElementResponse EchoSequenceSequenceElement - {http://www.w3.org/2002/ws/databinding/examples/6/09/}echoSequenceSequenceElement
  #
  def echoSequenceSequenceElement(echoSequenceSequenceElementRequest)
    p [echoSequenceSequenceElementRequest]
    return echoSequenceSequenceElementRequest
  end

  # SYNOPSIS
  #   echoDecimalSimpleTypeTotalDigits(echoDecimalSimpleTypeTotalDigitsRequest)
  #
  # ARGS
  #   echoDecimalSimpleTypeTotalDigitsRequest EchoDecimalSimpleTypeTotalDigits - {http://www.w3.org/2002/ws/databinding/examples/6/09/}echoDecimalSimpleTypeTotalDigits
  #
  # RETURNS
  #   echoDecimalSimpleTypeTotalDigitsResponse EchoDecimalSimpleTypeTotalDigits - {http://www.w3.org/2002/ws/databinding/examples/6/09/}echoDecimalSimpleTypeTotalDigits
  #
  def echoDecimalSimpleTypeTotalDigits(echoDecimalSimpleTypeTotalDigitsRequest)
    p [echoDecimalSimpleTypeTotalDigitsRequest]
    return echoDecimalSimpleTypeTotalDigitsRequest
  end

  # SYNOPSIS
  #   echoDecimalSimpleTypeFractionDigits(echoDecimalSimpleTypeFractionDigitsRequest)
  #
  # ARGS
  #   echoDecimalSimpleTypeFractionDigitsRequest EchoDecimalSimpleTypeFractionDigits - {http://www.w3.org/2002/ws/databinding/examples/6/09/}echoDecimalSimpleTypeFractionDigits
  #
  # RETURNS
  #   echoDecimalSimpleTypeFractionDigitsResponse EchoDecimalSimpleTypeFractionDigits - {http://www.w3.org/2002/ws/databinding/examples/6/09/}echoDecimalSimpleTypeFractionDigits
  #
  def echoDecimalSimpleTypeFractionDigits(echoDecimalSimpleTypeFractionDigitsRequest)
    p [echoDecimalSimpleTypeFractionDigitsRequest]
    return echoDecimalSimpleTypeFractionDigitsRequest
  end

  # SYNOPSIS
  #   echoAttributeTypeReference(echoAttributeTypeReferenceRequest)
  #
  # ARGS
  #   echoAttributeTypeReferenceRequest EchoAttributeTypeReference - {http://www.w3.org/2002/ws/databinding/examples/6/09/}echoAttributeTypeReference
  #
  # RETURNS
  #   echoAttributeTypeReferenceResponse EchoAttributeTypeReference - {http://www.w3.org/2002/ws/databinding/examples/6/09/}echoAttributeTypeReference
  #
  def echoAttributeTypeReference(echoAttributeTypeReferenceRequest)
    p [echoAttributeTypeReferenceRequest]
    return echoAttributeTypeReferenceRequest
  end

  # SYNOPSIS
  #   echoElementTypeReference(echoElementTypeReferenceRequest)
  #
  # ARGS
  #   echoElementTypeReferenceRequest EchoElementTypeReference - {http://www.w3.org/2002/ws/databinding/examples/6/09/}echoElementTypeReference
  #
  # RETURNS
  #   echoElementTypeReferenceResponse EchoElementTypeReference - {http://www.w3.org/2002/ws/databinding/examples/6/09/}echoElementTypeReference
  #
  def echoElementTypeReference(echoElementTypeReferenceRequest)
    p [echoElementTypeReferenceRequest]
    return echoElementTypeReferenceRequest
  end

  # SYNOPSIS
  #   echoLocalElementComplexType(echoLocalElementComplexTypeRequest)
  #
  # ARGS
  #   echoLocalElementComplexTypeRequest EchoLocalElementComplexType - {http://www.w3.org/2002/ws/databinding/examples/6/09/}echoLocalElementComplexType
  #
  # RETURNS
  #   echoLocalElementComplexTypeResponse EchoLocalElementComplexType - {http://www.w3.org/2002/ws/databinding/examples/6/09/}echoLocalElementComplexType
  #
  def echoLocalElementComplexType(echoLocalElementComplexTypeRequest)
    p [echoLocalElementComplexTypeRequest]
    return echoLocalElementComplexTypeRequest
  end

  # SYNOPSIS
  #   echoIdExample(echoIdExampleRequest)
  #
  # ARGS
  #   echoIdExampleRequest EchoIdExample - {http://www.w3.org/2002/ws/databinding/examples/6/09/}echoIdExample
  #
  # RETURNS
  #   echoIdExampleResponse EchoIdExample - {http://www.w3.org/2002/ws/databinding/examples/6/09/}echoIdExample
  #
  def echoIdExample(echoIdExampleRequest)
    p [echoIdExampleRequest]
    return echoIdExampleRequest
  end

  # SYNOPSIS
  #   echoAttributeGroupExample(echoAttributeGroupExampleRequest)
  #
  # ARGS
  #   echoAttributeGroupExampleRequest EchoAttributeGroupExample - {http://www.w3.org/2002/ws/databinding/examples/6/09/}echoAttributeGroupExample
  #
  # RETURNS
  #   echoAttributeGroupExampleResponse EchoAttributeGroupExample - {http://www.w3.org/2002/ws/databinding/examples/6/09/}echoAttributeGroupExample
  #
  def echoAttributeGroupExample(echoAttributeGroupExampleRequest)
    p [echoAttributeGroupExampleRequest]
    return echoAttributeGroupExampleRequest
  end
end

