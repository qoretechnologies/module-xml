. ../setenv.sh
export JAVA_HOME=d:/bea100/jdk150_06
export WEBLOGIC_HOME=d:/bea100/wlserver_10.0/server
