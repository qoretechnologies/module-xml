#!/bin/sh -e

exec ../gsoap2_2.7.10_c/genit.sh cpp
