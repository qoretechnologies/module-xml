using System;
using System.Collections.Generic;
using System.Text;
using System.Net;
using System.ServiceModel;
using System.ServiceModel.Description;

namespace DataBindingWorkingGroup
{
    class Program
    {
        static void Main(string[] args)
        {
            Uri baseAddress = new Uri("http://localhost:9001/PortType");
            ServiceHost host = new ServiceHost(typeof(PortTypeImpl),baseAddress);
            ServiceEndpoint ep = host.AddServiceEndpoint(typeof(PortType), new BasicHttpBinding(), "svc");
            host.Open();
            Console.ReadLine();
        }
    }
}

