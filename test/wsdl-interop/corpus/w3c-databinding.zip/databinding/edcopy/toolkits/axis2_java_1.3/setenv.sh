. ../setenv.sh
export JAVA_HOME=d:/bea100/jdk150_06
export AXIS2_HOME=d:/temp/axis2-1.3
export CATALINA_HOME=D:/temp/apache-tomcat-6.0.14
