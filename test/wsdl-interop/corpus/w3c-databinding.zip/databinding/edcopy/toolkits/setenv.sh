#
#  common environment
#
#  $Header: /w3ccvs/WWW/2002/ws/databinding/edcopy/toolkits/setenv.sh,v 1.5 2006/10/21 22:33:33 pdowney Exp $
#

#
#  default toolkit name
#  -the name of the current directory
#
export TOOLKIT=$(basename $PWD)

#
#  root of local copy of databinding files
#
[ -z "$DATABINDING_HOME" ]&&DATABINDING_HOME=../../..
export DATABINDING_HOME

#
#  local copy of testsuite examples files
#
export EXAMPLES_DIR=${DATABINDING_HOME}/examples/6/09
