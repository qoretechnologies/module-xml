<?xml version="1.0" encoding="utf-8"?>
<!-- 

    Copyright (C) 2006 W3C (R) (MIT ERCIM Keio), All Rights Reserved.
    W3C liability, trademark and document use rules apply.

    http://www.w3.org/Consortium/Legal/ipr-notice
    http://www.w3.org/Consortium/Legal/copyright-documents

    $Header: /w3ccvs/WWW/2002/ws/databinding/edcopy/patterns/exclusions.xsl,v 1.1 2006/10/20 16:51:46 pdowney Exp $

-->
<xsl:transform xmlns:xsl="http://www.w3.org/1999/XSL/Transform" version="1.0">

  <xsl:output method="text" />
  <xsl:template match="//exclude">:<xsl:value-of select="text()"/>:</xsl:template>

</xsl:transform>
